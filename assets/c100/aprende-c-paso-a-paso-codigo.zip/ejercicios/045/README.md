# Ejercicio 45

Fuente: 049-ejercicio-45-recorrer-array-usando-aritm-etica-de-punteros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
