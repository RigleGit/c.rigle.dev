#include <stdio.h>

int main(void) {
    int valores[] = {3, 7, 2, 8, 4};
    int suma = 0;
    int *ptr;

    // Recorremos el array usando aritmética de punteros
    for (ptr = valores; ptr < valores + 5; ptr++) {
        suma += *ptr;  // Accedemos al valor apuntado por ptr y lo sumamos
    }

    printf("La suma de los elementos es: %d\n", suma);

    return 0;
}
