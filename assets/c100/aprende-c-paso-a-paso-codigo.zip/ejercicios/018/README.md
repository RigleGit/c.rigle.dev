# Ejercicio 18

Fuente: 022-ejercicio-18-juego-de-adivinar-un-n-umero.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
