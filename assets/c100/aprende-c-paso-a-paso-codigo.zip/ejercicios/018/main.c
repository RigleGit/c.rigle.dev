#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
    int secreto, intento;

    // Inicializa el generador de números aleatorios con la hora actual
    srand(time(NULL));
    // Genera un número aleatorio entre 1 y 100
    secreto = rand() % 100 + 1;

    printf("Adivina el número (entre 1 y 100):\n");

    do {
        printf("Tu intento: ");
        if (scanf("%d", &intento) != 1) {
            fputs("Entrada inválida.\n", stderr);
            return 1;
        }

        if (intento < secreto) {
            printf("El número es mayor.\n");
        } else if (intento > secreto) {
            printf("El número es menor.\n");
        } else {
            printf("¡Correcto! Has adivinado el número.\n");
        }
    } while (intento != secreto);

    return 0;
}
