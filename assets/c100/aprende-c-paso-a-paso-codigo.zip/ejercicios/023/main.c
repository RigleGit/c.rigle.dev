#include <stdio.h>
#include <stdbool.h>

// Función que devuelve true si n es primo, false en caso contrario
bool esPrimo(int n) {
    if (n <= 1) return false;          // Números menores o iguales a 1 no son primos
    if (n == 2) return true;           // 2 es primo
    if (n % 2 == 0) return false;      // Los números pares mayores que 2 no son primos

    // Comprobar divisores impares sin multiplicación ni raíz flotante
    for (int i = 3; i <= n / i; i += 2) {
        if (n % i == 0) return false;
    }
    return true;
}

int main(void) {
    int limite;

    printf("Introduce un número entero positivo: ");
    if (scanf("%d", &limite) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (limite < 1) {
        fputs("El límite debe ser positivo.\n", stderr);
        return 1;
    }

    printf("Números primos hasta %d:\n", limite);
    for (int i = 2; i <= limite; i++) {
        if (esPrimo(i)) {
            printf("%d ", i);
        }
        // No incrementar después del último candidato, incluido INT_MAX
        if (i == limite) break;
    }
    printf("\n");

    return 0;
}
