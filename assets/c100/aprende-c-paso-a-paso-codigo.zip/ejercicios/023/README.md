# Ejercicio 23

Fuente: 027-ejercicio-23-funci-on-esprimo.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
