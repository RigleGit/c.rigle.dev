# Ejercicio 29

Fuente: 033-ejercicio-29-intercambiar-dos-variables-sin-auxiliar-uso-de-xor.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
