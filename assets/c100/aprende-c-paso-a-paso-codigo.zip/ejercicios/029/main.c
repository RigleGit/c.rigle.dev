#include <stdio.h>

int main(void) {
    int a, b;

    printf("Introduce el primer número (a): ");
    if (scanf("%d", &a) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    printf("Introduce el segundo número (b): ");
    if (scanf("%d", &b) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Intercambio sin variable auxiliar usando XOR
    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    printf("Después del intercambio: a = %d, b = %d\n", a, b);

    return 0;
}
