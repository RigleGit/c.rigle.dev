# Ejercicio 100

Fuente: 104-ejercicio-100-calculadora-en-notaci-on-postfija.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
