#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>

typedef struct Nodo {
    double valor;
    struct Nodo *siguiente;
} Nodo;

static int push(Nodo **cima, double valor) {
    Nodo *nuevo = malloc(sizeof(*nuevo));
    if (nuevo == NULL) return 0;
    nuevo->valor = valor;
    nuevo->siguiente = *cima;
    *cima = nuevo;
    return 1;
}

/* Solo se llama después de comprobar que la pila no está vacía. */
static double pop(Nodo **cima) {
    Nodo *nodo = *cima;
    double valor = nodo->valor;
    *cima = nodo->siguiente;
    free(nodo);
    return valor;
}

static void liberar(Nodo **cima) {
    while (*cima != NULL) (void)pop(cima);
}

static int convertir(const char *token, double *valor) {
    char *fin;
    errno = 0;
    *valor = strtod(token, &fin);
    return fin != token && *fin == '\0' &&
           errno == 0 && isfinite(*valor);
}

int main(void) {
    char entrada[256];
    Nodo *pila = NULL;
    int estado = 1;
    printf("Introduce expresión en notación postfija (RPN): ");
    if (fgets(entrada, sizeof(entrada), stdin) == NULL) {
        fputs("Error de lectura.\n", stderr);
        return 1;
    }
    size_t longitud = strcspn(entrada, "\n");
    if (longitud > 254 ||
        (entrada[longitud] != '\n' && !feof(stdin))) {
        fputs("La expresión supera el límite de la línea.\n", stderr);
        return 1;
    }
    entrada[longitud] = '\0';

    for (char *token = strtok(entrada, " \t\r");
         token != NULL; token = strtok(NULL, " \t\r")) {
        double valor;
        if (convertir(token, &valor)) {
            if (!push(&pila, valor)) {
                fputs("No hay memoria.\n", stderr);
                goto limpieza;
            }
        } else if (strlen(token) == 1 &&
                   strchr("+-*/", token[0]) != NULL) {
            if (pila == NULL || pila->siguiente == NULL) {
                fputs("Faltan operandos.\n", stderr);
                goto limpieza;
            }
            double b = pop(&pila), a = pop(&pila);
            switch (token[0]) {
                case '+': valor = a + b; break;
                case '-': valor = a - b; break;
                case '*': valor = a * b; break;
                case '/':
                    if (b == 0.0) {
                        fputs("División por cero.\n", stderr);
                        goto limpieza;
                    }
                    valor = a / b;
                    break;
            }
            if (!isfinite(valor)) {
                fputs("Resultado fuera del intervalo finito.\n", stderr);
                goto limpieza;
            }
            if (!push(&pila, valor)) {
                fputs("No hay memoria.\n", stderr);
                goto limpieza;
            }
        } else {
            fprintf(stderr, "Token inválido: %s\n", token);
            goto limpieza;
        }
    }
    if (pila == NULL || pila->siguiente != NULL) {
        fputs("Debe quedar exactamente un resultado.\n", stderr);
        goto limpieza;
    }
    printf("Resultado: %.2f\n", pop(&pila));
    estado = 0;

limpieza:
    liberar(&pila);
    return estado;
}
