# Ejercicio 40

Fuente: 044-ejercicio-40-invertir-una-cadena-de-caracteres.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
