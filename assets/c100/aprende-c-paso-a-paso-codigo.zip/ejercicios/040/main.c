#include <stdio.h>
#include <string.h>

int main(void) {
    char cadena[100];

    // Pedir al usuario que introduzca una cadena
    printf("Introduce una cadena: ");
    if (fgets(cadena, sizeof(cadena), stdin) == NULL) {
        return 1;
    }

    // Eliminar el salto de línea al final si está presente
    size_t len = strlen(cadena);
    if (len > 0 && cadena[len - 1] == '\n') {
        cadena[len - 1] = '\0';
        len--;
    } else {
        // Si falta el salto, comprobar el byte siguiente de la entrada
        int siguiente = getchar();
        if (siguiente != '\n' && (siguiente != EOF || ferror(stdin))) {
            fputs("Línea demasiado larga o error de lectura.\n",
                  stderr);
            return 1;
        }
    }

    // Imprimir la cadena invertida
    printf("Cadena invertida: ");
    for (size_t i = len; i > 0; i--) {
        putchar(cadena[i - 1]);
    }
    printf("\n");

    return 0;
}
