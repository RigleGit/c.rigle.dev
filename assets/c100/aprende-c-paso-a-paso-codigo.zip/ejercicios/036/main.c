#include <stdio.h>
#include <limits.h>

#define FILAS 3
#define COLUMNAS 3

int main(void) {
    int A[FILAS][COLUMNAS];
    int B[FILAS][COLUMNAS];
    int resultado[FILAS][COLUMNAS];

    // Leer elementos de la primera matriz
    printf("Introduce los elementos de la primera matriz (3x3):\n");
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            printf("A[%d][%d]: ", i, j);
            if (scanf("%d", &A[i][j]) != 1) {
                fputs("Entrada inválida.\n", stderr);
                return 1;
            }
        }
    }

    // Leer elementos de la segunda matriz
    printf("Introduce los elementos de la segunda matriz (3x3):\n");
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            printf("B[%d][%d]: ", i, j);
            if (scanf("%d", &B[i][j]) != 1) {
                fputs("Entrada inválida.\n", stderr);
                return 1;
            }
        }
    }

    // Sumar las dos matrices elemento a elemento
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            int a = A[i][j], b = B[i][j];
            if ((b > 0 && a > INT_MAX - b) ||
                (b < 0 && a < INT_MIN - b)) {
                fputs("La suma no cabe en int.\n", stderr);
                return 1;
            }
            resultado[i][j] = a + b;
        }
    }

    // Mostrar la matriz resultado
    printf("Matriz resultante de la suma:\n");
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            printf("%d\t", resultado[i][j]);
        }
        printf("\n");
    }

    return 0;
}
