# Ejercicio 36

Fuente: 040-ejercicio-36-suma-de-dos-matrices.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
