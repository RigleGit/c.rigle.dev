# Ejercicio 94

Fuente: 098-ejercicio-94-eliminando-buffer-overflow.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
