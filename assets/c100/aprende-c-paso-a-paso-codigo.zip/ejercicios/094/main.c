#include <stdio.h>
#include <string.h>

int main(void) {
    char nombre[10];

    printf("Introduce tu nombre: ");
    if (fgets(nombre, sizeof(nombre), stdin)) {
        // Eliminar el salto de línea si quedó almacenado
        nombre[strcspn(nombre, "\n")] = '\0';
        printf("Hola, %s\n", nombre);
    } else {
        printf("Error al leer la entrada.\n");
    }

    return 0;
}
