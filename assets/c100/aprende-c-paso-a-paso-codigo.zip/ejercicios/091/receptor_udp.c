#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PUERTO 9090
#define BUFFER 1024

int main(void) {
    int sockfd;
    struct sockaddr_in servidor;
    struct sockaddr_in cliente;
    socklen_t tam_cliente = sizeof(cliente);
    char buffer[BUFFER];

    // 1) Crear socket UDP
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error al crear socket");
        exit(EXIT_FAILURE);
    }

    // 2) Configurar dirección local
    memset(&servidor, 0, sizeof(servidor));
    servidor.sin_family = AF_INET;
    servidor.sin_addr.s_addr = htonl(INADDR_ANY);
    servidor.sin_port = htons(PUERTO);

    // 3) Asociar socket a puerto
    if (bind(sockfd, (struct sockaddr*)&servidor, sizeof(servidor)) < 0) {
        perror("Error en bind");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Esperando mensajes UDP en puerto %d...\n", PUERTO);

    // 4) Recibir un datagrama (bloqueante)
    int leido = recvfrom(sockfd, buffer, BUFFER - 1, 0,
                         (struct sockaddr*)&cliente, &tam_cliente);
    if (leido < 0) {
        perror("Error en recvfrom");
        close(sockfd);
        return 1;
    }

    buffer[leido] = '\0'; // terminar como cadena
    char ip_cliente[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &cliente.sin_addr, ip_cliente, sizeof(ip_cliente));
    printf("[%s:%d] %s\n", ip_cliente, ntohs(cliente.sin_port), buffer);

    close(sockfd);
    return 0;
}
