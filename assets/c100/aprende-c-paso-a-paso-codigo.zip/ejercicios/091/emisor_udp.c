#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PUERTO   9090
#define MENSAJE "Hola desde el cliente UDP"

int main(void) {
    int sockfd;
    struct sockaddr_in servidor;

    // 1) Crear socket UDP
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error al crear socket");
        exit(EXIT_FAILURE);
    }

    // 2) Configurar dirección del servidor
    memset(&servidor, 0, sizeof(servidor));
    servidor.sin_family = AF_INET;
    servidor.sin_port = htons(PUERTO);
    if (inet_pton(AF_INET, "127.0.0.1", &servidor.sin_addr) != 1) {
        fprintf(stderr, "IP destino inválida\n");
        close(sockfd);
        return 1;
    }

    // 3) Enviar datagrama
    ssize_t enviados = sendto(sockfd, MENSAJE, strlen(MENSAJE), 0,
                              (struct sockaddr*)&servidor, sizeof(servidor));
    if (enviados < 0) {
        perror("Error en sendto");
        close(sockfd);
        return 1;
    }

    printf("Mensaje enviado al servidor UDP (%zd bytes)\n", enviados);

    close(sockfd);
    return 0;
}
