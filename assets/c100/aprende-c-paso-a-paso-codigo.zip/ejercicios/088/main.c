#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#include <string.h>

static void comprobar_pthread(int error, const char *operacion) {
    if (error != 0) {
        fprintf(stderr, "%s: %s\n", operacion, strerror(error));
        exit(EXIT_FAILURE);
    }
}

#define TAM_BUFFER 10
#define NUM_DATOS  50

// Búfer circular y estado
int buffer[TAM_BUFFER];
int in = 0;      // índice de escritura
int out = 0;     // índice de lectura
int contador = 0; // número de elementos en el búfer

// Sincronización
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_lleno = PTHREAD_COND_INITIALIZER;  // esperar si está lleno
pthread_cond_t cond_vacio = PTHREAD_COND_INITIALIZER;  // esperar si está vacío

void* productor(void* arg) {
    (void)arg;
    for (int i = 0; i < NUM_DATOS; i++) {
        int dato = rand() % 100; // produce un valor

        comprobar_pthread(pthread_mutex_lock(&mutex), "pthread_mutex_lock");
        while (contador == TAM_BUFFER) {              // búfer lleno
            comprobar_pthread(pthread_cond_wait(&cond_lleno, &mutex), "pthread_cond_wait");   // espera espacio
        }
        buffer[in] = dato;                            // insertar
        in = (in + 1) % TAM_BUFFER;                   // avanzar índice
        contador++;
        printf("Producido: %d\n", dato);
        comprobar_pthread(pthread_cond_signal(&cond_vacio), "pthread_cond_signal");             // hay datos
        comprobar_pthread(pthread_mutex_unlock(&mutex), "pthread_mutex_unlock");

        struct timespec pausa = {0, 100000000};
        nanosleep(&pausa, NULL); // simula producción lenta
    }
    return NULL;
}

void* consumidor(void* arg) {
    (void)arg;
    for (int i = 0; i < NUM_DATOS; i++) {
        comprobar_pthread(pthread_mutex_lock(&mutex), "pthread_mutex_lock");
        while (contador == 0) {                       // búfer vacío
            comprobar_pthread(pthread_cond_wait(&cond_vacio, &mutex), "pthread_cond_wait");   // espera datos
        }
        int dato = buffer[out];                       // extraer
        out = (out + 1) % TAM_BUFFER;                 // avanzar índice
        contador--;
        printf("Consumido: %d\n", dato);
        comprobar_pthread(pthread_cond_signal(&cond_lleno), "pthread_cond_signal");             // hay hueco
        comprobar_pthread(pthread_mutex_unlock(&mutex), "pthread_mutex_unlock");

        struct timespec pausa = {0, 150000000};
        nanosleep(&pausa, NULL); // simula consumo lento
    }
    return NULL;
}

int main(void) {
    srand((unsigned)time(NULL));

    pthread_t hilo_prod, hilo_cons;
    comprobar_pthread(pthread_create(&hilo_prod, NULL, productor, NULL), "pthread_create");
    comprobar_pthread(pthread_create(&hilo_cons, NULL, consumidor, NULL), "pthread_create");

    comprobar_pthread(pthread_join(hilo_prod, NULL), "pthread_join");
    comprobar_pthread(pthread_join(hilo_cons, NULL), "pthread_join");

    comprobar_pthread(pthread_cond_destroy(&cond_lleno), "pthread_cond_destroy");
    comprobar_pthread(pthread_cond_destroy(&cond_vacio), "pthread_cond_destroy");
    comprobar_pthread(pthread_mutex_destroy(&mutex), "pthread_mutex_destroy");
    return 0;
}
