# Ejercicio 88

Fuente: 092-ejercicio-88-productor-consumidor-con-b-ufer.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
