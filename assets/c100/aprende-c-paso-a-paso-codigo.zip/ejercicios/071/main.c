#include <stdio.h>

// Intercambia dos enteros por referencia
void intercambiar(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Coloca el pivote en su posición correcta y
// deja menores/iguales a la izquierda y mayores a la derecha
int particionar(int arr[], int bajo, int alto) {
    int pivote = arr[alto];         // pivote: último elemento
    int i = bajo - 1;               // índice del menor

    for (int j = bajo; j < alto; j++) {
        if (arr[j] <= pivote) {
            i++;
            intercambiar(&arr[i], &arr[j]);
        }
    }
    intercambiar(&arr[i + 1], &arr[alto]);
    return i + 1;                   // posición final del pivote
}

// Quicksort recursivo sobre el rango [bajo, alto]
void quicksort(int arr[], int bajo, int alto) {
    if (bajo < alto) {
        int pi = particionar(arr, bajo, alto);
        quicksort(arr, bajo, pi - 1);
        quicksort(arr, pi + 1, alto);
    }
}

// Utilidad para imprimir el array
void imprimirArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main(void) {
    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = (int)(sizeof(arr) / sizeof(arr[0]));

    printf("Array original:\n");
    imprimirArray(arr, n);

    quicksort(arr, 0, n - 1);

    printf("Array ordenado:\n");
    imprimirArray(arr, n);

    return 0;
}
