# Ejercicio 71

Fuente: 075-ejercicio-71-ordenamiento-r-apido-quicksort-recursivo.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
