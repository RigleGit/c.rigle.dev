# Ejercicio 24

Fuente: 028-ejercicio-24-funci-on-mcd-m-aximo-com-un-divisor.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
