#include <stdio.h>

// Función que calcula el máximo común divisor usando el algoritmo de Euclides (recursiva)
int mcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return mcd(b, a % b);
}

int main(void) {
    int num1, num2;

    // Solicitar al usuario los dos números
    printf("Introduce el primer número: ");
    if (scanf("%d", &num1) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    printf("Introduce el segundo número: ");
    if (scanf("%d", &num2) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (num1 < 0 || num2 < 0 || (num1 == 0 && num2 == 0)) {
        fputs("Usa números no negativos, al menos uno distinto de cero.\n", stderr);
        return 1;
    }

    // Calcular y mostrar el MCD
    int resultado = mcd(num1, num2);
    printf("El MCD de %d y %d es: %d\n", num1, num2, resultado);

    return 0;
}
