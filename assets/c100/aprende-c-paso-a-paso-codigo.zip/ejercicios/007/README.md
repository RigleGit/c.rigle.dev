# Ejercicio 7

Fuente: 011-ejercicio-7-distancia-entre-dos-puntos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
