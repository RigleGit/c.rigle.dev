#include <stdio.h>
#include <math.h>

int main(void) {
    double x1, y1, x2, y2;
    double dx, dy, distancia;

    printf("Introduce las coordenadas del primer punto (x1 y1): ");
    scanf("%lf %lf", &x1, &y1);

    printf("Introduce las coordenadas del segundo punto (x2 y2): ");
    scanf("%lf %lf", &x2, &y2);

    dx = x2 - x1;
    dy = y2 - y1;
    distancia = sqrt(dx * dx + dy * dy);

    printf("La distancia entre los dos puntos es: %.2f\n", distancia);

    return 0;
}
