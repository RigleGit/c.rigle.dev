#include <stdio.h>

int main(void) {
    int total_segundos, horas, minutos, segundos;

    printf("Introduce el total de segundos: ");
    scanf("%d", &total_segundos);

    horas = total_segundos / 3600;
    minutos = (total_segundos % 3600) / 60;
    segundos = total_segundos % 60;

    printf("Equivalente: %02d:%02d:%02d\n", horas, minutos, segundos);

    return 0;
}
