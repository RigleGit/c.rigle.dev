# Ejercicio 5

Fuente: 009-ejercicio-5-conversi-on-de-segundos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
