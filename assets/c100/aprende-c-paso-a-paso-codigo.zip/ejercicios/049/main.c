#include <stdio.h>

int main(void) {
    int numero = 4660; // Valor conocido: 0x1234 en hexadecimal

    // Puntero a unsigned char para acceder byte a byte
    unsigned char *ptr = (unsigned char *)&numero;

    printf("Bytes en memoria de %d:\n", numero);

    // Recorremos cada byte de la variable 'numero'
    for (size_t i = 0; i < sizeof(int); i++) {
        printf("Byte %zu: 0x%02X\n", i, (unsigned int)ptr[i]);
    }

    return 0;
}
