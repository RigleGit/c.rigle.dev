# Ejercicio 49

Fuente: 053-ejercicio-49-inspeccionar-bytes-de-un-entero.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
