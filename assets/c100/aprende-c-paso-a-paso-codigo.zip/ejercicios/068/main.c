#include <stdio.h>
#include <stdlib.h>

typedef struct NodoArbol {
    int valor;
    struct NodoArbol* izq;
    struct NodoArbol* der;
} NodoArbol;

// Inserta un valor en el árbol binario de búsqueda
NodoArbol* insertar(NodoArbol* raiz, int valor) {
    if (raiz == NULL) {
        NodoArbol* nuevo = malloc(sizeof(NodoArbol));
        if (nuevo == NULL) {
            fputs("No se pudo reservar el nodo.\n", stderr);
            exit(EXIT_FAILURE);
        }
        nuevo->valor = valor;
        nuevo->izq = nuevo->der = NULL;
        return nuevo;
    }

    if (valor < raiz->valor) {
        raiz->izq = insertar(raiz->izq, valor);
    } else if (valor > raiz->valor) {
        raiz->der = insertar(raiz->der, valor);
    }
    // Si es igual, no se inserta para evitar duplicados

    return raiz;
}

// Recorrido in-order: izquierda - raíz - derecha
void recorridoInOrder(NodoArbol* raiz) {
    if (raiz != NULL) {
        recorridoInOrder(raiz->izq);
        printf("%d ", raiz->valor);
        recorridoInOrder(raiz->der);
    }
}

// Liberar memoria del árbol
void liberarArbol(NodoArbol* raiz) {
    if (raiz != NULL) {
        liberarArbol(raiz->izq);
        liberarArbol(raiz->der);
        free(raiz);
    }
}

int main(void) {
    NodoArbol* arbol = NULL;
    int valores[] = {7, 3, 9, 1, 5, 8, 10};
    int n = sizeof(valores) / sizeof(valores[0]);

    for (int i = 0; i < n; i++) {
        arbol = insertar(arbol, valores[i]);
    }

    printf("Recorrido in-order del árbol: ");
    recorridoInOrder(arbol);
    printf("\n");

    liberarArbol(arbol);
    return 0;
}
