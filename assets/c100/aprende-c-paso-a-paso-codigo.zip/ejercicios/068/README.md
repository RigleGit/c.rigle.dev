# Ejercicio 68

Fuente: 072-ejercicio-68-arbol-binario-de-b-usqueda.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
