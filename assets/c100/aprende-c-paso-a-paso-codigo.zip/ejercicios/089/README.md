# Ejercicio 89

Fuente: 093-ejercicio-89-cliente-tcp-sencillo.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
