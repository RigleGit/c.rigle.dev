#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>

#define PUERTO 8080
#define MENSAJE "Hola, servidor"
#define BUFFER 1024

int main(void) {
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) return 1;
    int sockfd;
    struct sockaddr_in servidor = {0};
    char buffer[BUFFER];

    // Crear el socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Error al crear el socket");
        exit(EXIT_FAILURE);
    }

    // Configurar dirección del servidor
    servidor.sin_family = AF_INET;
    servidor.sin_port = htons(PUERTO);
    servidor.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Conectar al servidor
    if (connect(sockfd, (struct sockaddr *)&servidor, sizeof(servidor)) < 0) {
        perror("Error al conectar al servidor");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Completar el envío y anunciar que no habrá más datos.
    size_t enviados = 0, longitud = strlen(MENSAJE);
    while (enviados < longitud) {
        ssize_t n = send(sockfd, &MENSAJE[enviados],
                         longitud - enviados, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) {
            fputs("Error al enviar.\n", stderr);
            close(sockfd);
            return 1;
        }
        enviados += (size_t)n;
    }
    if (shutdown(sockfd, SHUT_WR) < 0) {
        perror("shutdown");
        close(sockfd);
        return 1;
    }
    printf("Respuesta del servidor: ");
    for (;;) {
        ssize_t n = recv(sockfd, buffer, sizeof(buffer), 0);
        if (n < 0 && errno == EINTR) continue;
        if (n < 0) {
            perror("recv");
            close(sockfd);
            return 1;
        }
        if (n == 0) break;
        if (fwrite(buffer, 1, (size_t)n, stdout) != (size_t)n) {
            close(sockfd);
            return 1;
        }
    }
    putchar('\n');

    // Cerrar socket
    close(sockfd);

    return 0;
}
