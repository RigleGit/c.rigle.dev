#include <stdio.h>

int main(void) {
    int a, b;

    // Solicitar al usuario que introduzca el primer número
    printf("Introduce el primer número: ");
    if (scanf("%d", &a) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Solicitar al usuario que introduzca el segundo número
    printf("Introduce el segundo número: ");
    if (scanf("%d", &b) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Comparar los dos números y mostrar el resultado
    if (a > b) {
        printf("El mayor es: %d\n", a);
    } else if (b > a) {
        printf("El mayor es: %d\n", b);
    } else {
        printf("Ambos números son iguales.\n");
    }

    return 0;
}
