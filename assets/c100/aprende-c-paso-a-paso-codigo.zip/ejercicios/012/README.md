# Ejercicio 12

Fuente: 016-ejercicio-12-m-aximo-de-dos-n-umeros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
