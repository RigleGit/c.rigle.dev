#include <stdio.h>
#include <limits.h>

long factorial(int n) {
    if (n < 0 || n > 20) return 0;
    if (n < 2) return 1;
    long anterior = factorial(n - 1);
    if (anterior == 0 || anterior > LONG_MAX / n) return 0;
    return anterior * n;
}

int main(void) {
    int n;
    printf("Introduce un número entero no negativo: ");
    if (scanf("%d", &n) != 1) {
        fprintf(stderr, "Entrada inválida.\n");
        return 1;
    }
    long resultado = factorial(n);
    if (resultado == 0) {
        fprintf(stderr, "Argumento fuera de rango o resultado no representable.\n");
        return 1;
    }
    printf("El factorial de %d es: %ld\n", n, resultado);
    return 0;
}
