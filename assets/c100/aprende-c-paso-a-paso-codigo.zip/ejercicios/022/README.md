# Ejercicio 22

Fuente: 026-ejercicio-22-factorial-funci-on-recursiva.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
