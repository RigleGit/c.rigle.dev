#include <stdio.h>

int main(void) {
    double num1, num2, num3, promedio;

    printf("Introduce tres números (pueden tener decimales): ");
    scanf("%lf %lf %lf", &num1, &num2, &num3);

    promedio = (num1 + num2 + num3) / 3.0;

    printf("El promedio es: %.2f\n", promedio);

    return 0;
}
