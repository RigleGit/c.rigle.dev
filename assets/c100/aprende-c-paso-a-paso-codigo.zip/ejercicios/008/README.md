# Ejercicio 8

Fuente: 012-ejercicio-8-promedio-de-tres-n-umeros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
