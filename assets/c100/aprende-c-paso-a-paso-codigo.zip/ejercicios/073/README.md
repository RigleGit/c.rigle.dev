# Ejercicio 73

Fuente: 077-ejercicio-73-comunicaci-on-entre-hilos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
