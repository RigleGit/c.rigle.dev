#include <stdio.h>
#include <string.h>

int main(void) {
    char texto[256];
    printf("Introduce una línea de texto para guardar en el archivo:\n");
    if (fgets(texto, sizeof texto, stdin) == NULL) {
        fputs("No se pudo leer una línea de entrada.\n", stderr);
        return 1;
    }

    FILE *f = fopen("salida.txt", "w");
    if (f == NULL) {
        perror("No se pudo abrir el archivo");
        return 1;
    }

    int error = 0;
    for (;;) {
        if (fputs(texto, f) == EOF) {
            error = 1;
            break;
        }
        if (strchr(texto, '\n') != NULL) break;
        if (fgets(texto, sizeof texto, stdin) == NULL) {
            if (ferror(stdin)) error = 1;
            break;
        }
    }
    if (fclose(f) == EOF) error = 1;
    if (error) {
        fputs("No se pudo guardar la línea completa.\n", stderr);
        return 1;
    }
    puts("Texto guardado correctamente en 'salida.txt'");
    return 0;
}
