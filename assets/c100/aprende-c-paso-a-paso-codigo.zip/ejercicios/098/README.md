# Ejercicio 98

Fuente: 102-ejercicio-98-manejo-adecuado-de-errores-de-funciones.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
