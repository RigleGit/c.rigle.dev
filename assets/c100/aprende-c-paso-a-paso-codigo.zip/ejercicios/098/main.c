#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int estado = 1;
    FILE *archivo = fopen("datos.txt", "r");
    if (archivo == NULL) {
        perror("datos.txt");
        return 1;
    }
    int *numeros = malloc(10 * sizeof(*numeros));
    if (numeros == NULL) {
        fputs("No se pudo reservar memoria.\n", stderr);
        if (fclose(archivo) == EOF) perror("fclose");
        return 1;
    }
    for (int i = 0; i < 10; ++i) {
        if (fscanf(archivo, "%d", &numeros[i]) != 1) {
            fputs("El archivo debe contener diez enteros válidos.\n",
                  stderr);
            goto limpieza;
        }
    }
    int umbral;
    printf("Introduce el umbral: ");
    if (scanf("%d", &umbral) != 1) {
        fputs("Umbral inválido.\n", stderr);
        goto limpieza;
    }
    printf("Valores mayores que %d:", umbral);
    for (int i = 0; i < 10; ++i) {
        if (numeros[i] > umbral) printf(" %d", numeros[i]);
    }
    putchar('\n');
    estado = 0;

limpieza:
    free(numeros);
    if (fclose(archivo) == EOF) {
        perror("fclose");
        estado = 1;
    }
    return estado;
}
