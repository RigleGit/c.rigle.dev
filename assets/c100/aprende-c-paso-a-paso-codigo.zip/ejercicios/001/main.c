#include <stdio.h>

int main(void) {
    // Imprime el mensaje "Hola Mundo" en la pantalla
    printf("Hola Mundo\n");
    return 0;
}
