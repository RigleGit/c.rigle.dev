# Ejercicio 1

Fuente: 005-ejercicio-1-hola-mundo.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
