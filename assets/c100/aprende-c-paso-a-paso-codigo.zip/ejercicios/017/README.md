# Ejercicio 17

Fuente: 021-ejercicio-17-suma-de-los-d-igitos-de-un-n-umero-bucle-while.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
