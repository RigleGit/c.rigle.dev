#include <stdio.h>

int main(void) {
    int numero, suma = 0;

    // Solicita un número entero no negativo al usuario
    printf("Introduce un número entero no negativo: ");
    if (scanf("%d", &numero) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (numero < 0) {
        // Rechaza los negativos antes de extraer dígitos
        fputs("El número debe ser no negativo.\n", stderr);
        return 1;
    } else {
        // Bucle que suma los dígitos uno a uno
        while (numero > 0) {
            suma += numero % 10;   // Suma el último dígito
            numero /= 10;          // Elimina el último dígito
        }
        printf("La suma de los dígitos es: %d\n", suma);
    }
    return 0;
}
