# Ejercicio 20

Fuente: 024-ejercicio-20-n-umeros-primos-hasta-n.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
