#include <stdio.h>

int main(void) {
    int N;

    printf("Introduce un número entero positivo: ");
    if (scanf("%d", &N) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (N < 2 || N > 100000) {
        fputs("Introduce N entre 2 y 100000.\n", stderr);
        return 1;
    }

    for (int num = 2; num <= N; num++) {
        int esPrimo = 1; // Suponemos que num es primo

        for (int i = 2; i <= num / i; i++) {
            if (num % i == 0) {
                esPrimo = 0; // num no es primo
                break;
            }
        }

        if (esPrimo) {
            printf("%d ", num);
        }
        // Termina antes del incremento final
        if (num == N) break;
    }

    printf("\n");
    return 0;
}
