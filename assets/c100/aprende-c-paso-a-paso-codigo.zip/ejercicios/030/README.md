# Ejercicio 30

Fuente: 034-ejercicio-30-empaquetar-dos-bytes-en-un-entero-de-16-bits.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
