#include <stdio.h>
#include <stdint.h>

int main(void) {
    unsigned int alto, bajo;
    printf("Introduce el primer byte (0-255): ");
    if (scanf("%u", &alto) != 1 || alto > 255) {
        fputs("Primer byte inválido.\n", stderr);
        return 1;
    }
    printf("Introduce el segundo byte (0-255): ");
    if (scanf("%u", &bajo) != 1 || bajo > 255) {
        fputs("Segundo byte inválido.\n", stderr);
        return 1;
    }
    uint_least16_t empaquetado =
        (uint_least16_t)((alto << 8) | bajo);
    printf("Valor empaquetado (hex): 0x%04X\n",
           (unsigned int)empaquetado);
    printf("Valor empaquetado (decimal): %u\n",
           (unsigned int)empaquetado);
    return 0;
}
