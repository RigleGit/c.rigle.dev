#include <stdio.h>
#include <stdlib.h>

// Definición del nodo de la lista enlazada
typedef struct Nodo {
    int valor;
    struct Nodo* siguiente;
} Nodo;

// Definición de la cola con punteros a frente y final
typedef struct {
    Nodo* frente;
    Nodo* final;
} Cola;

// Inserta un elemento al final de la cola (enqueue)
void enqueue(Cola* cola, int valor) {
    Nodo* nuevo = malloc(sizeof(Nodo));
    if (!nuevo) {
        printf("Error al reservar memoria.\n");
        exit(1);
    }
    nuevo->valor = valor;
    nuevo->siguiente = NULL;

    if (cola->final != NULL) {
        cola->final->siguiente = nuevo;
    } else {
        cola->frente = nuevo;
    }
    cola->final = nuevo;
}

// Retira un elemento del frente de la cola (dequeue)
int dequeue(Cola* cola) {
    if (cola->frente == NULL) {
        printf("Cola vacía.\n");
        return -1;
    }

    Nodo* temp = cola->frente;
    int valor = temp->valor;
    cola->frente = temp->siguiente;

    if (cola->frente == NULL) {
        cola->final = NULL;
    }

    free(temp);
    return valor;
}

// Imprime el contenido de la cola
void imprimirCola(Cola cola) {
    Nodo* actual = cola.frente;
    printf("Cola: ");
    while (actual != NULL) {
        printf("%d -> ", actual->valor);
        actual = actual->siguiente;
    }
    printf("NULL\n");
}

int main(void) {
    Cola cola = {NULL, NULL};

    enqueue(&cola, 5);
    enqueue(&cola, 10);
    enqueue(&cola, 15);
    imprimirCola(cola);

    printf("Atendiendo: %d\n", dequeue(&cola));
    imprimirCola(cola);

    enqueue(&cola, 20);
    imprimirCola(cola);

    while (cola.frente != NULL) {
        (void)dequeue(&cola);
    }
    return 0;
}
