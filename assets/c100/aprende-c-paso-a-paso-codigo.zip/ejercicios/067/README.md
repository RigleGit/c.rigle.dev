# Ejercicio 67

Fuente: 071-ejercicio-67-cola-implementada-con-lista-enlazada.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
