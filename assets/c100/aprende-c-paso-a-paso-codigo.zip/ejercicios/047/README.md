# Ejercicio 47

Fuente: 051-ejercicio-47-puntero-a-funci-on.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
