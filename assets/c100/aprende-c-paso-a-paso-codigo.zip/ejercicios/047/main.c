#include <stdio.h>

// Función que suma dos enteros
int sumar(int a, int b) {
    return a + b;
}

int main(void) {
    // Declaración de un puntero a función que recibe dos int y devuelve un int
    int (*ptrFuncion)(int, int);

    // Asignación de la dirección de la función 'sumar' al puntero
    ptrFuncion = &sumar;

    // Llamada a la función a través del puntero
    int resultado = ptrFuncion(10, 5);

    printf("Resultado: %d\n", resultado);

    return 0;
}
