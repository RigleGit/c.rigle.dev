# Ejercicio 48

Fuente: 052-ejercicio-48-funci-on-buscar-car-acter-propia.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
