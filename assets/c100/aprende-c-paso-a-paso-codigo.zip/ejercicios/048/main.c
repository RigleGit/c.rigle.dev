#include <stdio.h>

char *buscarCaracter(char *str, char c) {
    for (;;) {
        if (*str == c) return str;
        if (*str == '\0') return NULL;
        str++;
    }
}

int main(void) {
    char texto[] = "Hola mundo";
    char *resultado = buscarCaracter(texto, 'm');
    if (resultado != NULL) {
        printf("Posición: %td\n", resultado - texto);
    } else {
        puts("No encontrado.");
    }
    return 0;
}
