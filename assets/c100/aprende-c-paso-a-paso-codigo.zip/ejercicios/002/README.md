# Ejercicio 2

Fuente: 006-ejercicio-2-suma-de-dos-n-umeros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
