# Ejercicio 33

Fuente: 037-ejercicio-33-valor-m-inimo-y-m-aximo-en-un-array.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
