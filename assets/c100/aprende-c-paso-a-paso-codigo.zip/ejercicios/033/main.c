#include <stdio.h>

#define MAX 100

int main(void) {
    int numeros[MAX];
    int n;
    int min, max;

    printf("¿Cuántos números vas a introducir (máximo %d)? ", MAX);
    if (scanf("%d", &n) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (n < 1 || n > MAX) {
        printf("Cantidad inválida.\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        printf("Introduce el número %d: ", i + 1);
        if (scanf("%d", &numeros[i]) != 1) {
            fputs("Entrada inválida.\n", stderr);
            return 1;
        }
        // Inicializar min y max con el primer elemento
        if (i == 0) {
            min = max = numeros[i];
        } else {
            // Actualizar min si el nuevo número es menor
            if (numeros[i] < min)
                min = numeros[i];
            // Actualizar max si el nuevo número es mayor
            if (numeros[i] > max)
                max = numeros[i];
        }
    }

    printf("Valor mínimo: %d\n", min);
    printf("Valor máximo: %d\n", max);
    return 0;
}
