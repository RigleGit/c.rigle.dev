#include <stdio.h>

int main(void) {
    int numero;

    // Solicita al usuario que introduzca un número entero
    printf("Introduce un número entero: ");
    if (scanf("%d", &numero) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Determina si el número es positivo, negativo o cero
    if (numero > 0) {
        printf("El número es positivo.\n");
    } else if (numero < 0) {
        printf("El número es negativo.\n");
    } else {
        printf("El número es cero.\n");
    }

    return 0;
}
