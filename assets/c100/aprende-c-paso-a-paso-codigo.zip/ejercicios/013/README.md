# Ejercicio 13

Fuente: 017-ejercicio-13-positivo-negativo-o-cero.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
