# Ejercicio 57

Fuente: 061-ejercicio-57-definir-y-usar-una-estructura.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
