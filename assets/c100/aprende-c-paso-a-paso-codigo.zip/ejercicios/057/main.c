#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 100

// Definición de la estructura Persona con typedef para simplificar su uso
typedef struct {
    char nombre[MAX_NOMBRE]; // Campo para almacenar el nombre
    int edad;                // Campo para almacenar la edad
} Persona;

int main(void) {
    Persona p; // Declaración de una variable de tipo Persona

    // Copiar el nombre al array de la estructura
    strcpy(p.nombre, "Ana López");

    // Asignación directa de la edad
    p.edad = 28;

    // Mostrar los valores almacenados en la estructura
    printf("Nombre: %s\n", p.nombre);
    printf("Edad: %d\n", p.edad);

    return 0;
}
