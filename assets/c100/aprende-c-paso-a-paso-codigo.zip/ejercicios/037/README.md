# Ejercicio 37

Fuente: 041-ejercicio-37-multiplicaci-on-de-matrices.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
