# Ejercicio 43

Fuente: 047-ejercicio-43-introducci-on-a-punteros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
