#include <stdio.h>

int main(void) {
    int numero = 10;           // Declaración de una variable entera
    int *puntero = &numero;    // Declaración y asignación del puntero a la dirección de 'numero'

    // Imprimir valor y dirección antes de la modificación
    printf("Antes de modificar:\n");
    printf("Valor de numero: %d\n", numero);
    printf("Dirección de numero: %p\n", (void *)&numero);
    printf("Valor apuntado por puntero: %d\n", *puntero);
    printf("Dirección almacenada en puntero: %p\n", (void *)puntero);

    // Modificar el valor a través del puntero
    *puntero = 25;

    // Imprimir valor y dirección después de la modificación
    printf("\nDespués de modificar:\n");
    printf("Valor de numero: %d\n", numero);
    printf("Valor apuntado por puntero: %d\n", *puntero);
    printf("Dirección de numero: %p\n", (void *)&numero);
    printf("Dirección almacenada en puntero: %p\n", (void *)puntero);

    return 0;
}
