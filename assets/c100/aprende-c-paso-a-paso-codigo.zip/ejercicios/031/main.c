#include <stdio.h>

#define MAX 100

int main(void) {
    int numeros[MAX];
    int n;

    // Solicitar al usuario la cantidad de números a introducir
    printf("¿Cuántos números quieres introducir (máximo %d)? ", MAX);
    if (scanf("%d", &n) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Validar que n esté dentro del rango permitido
    if (n < 1 || n > MAX) {
        printf("Cantidad inválida.\n");
        return 1;
    }

    // Leer los números y almacenarlos en el array
    for (int i = 0; i < n; i++) {
        printf("Introduce el número %d: ", i + 1);
        if (scanf("%d", &numeros[i]) != 1) {
            fputs("Entrada inválida.\n", stderr);
            return 1;
        }
    }

    // Imprimir los números en orden inverso
    printf("Los números en orden inverso son:\n");
    for (int i = n - 1; i >= 0; i--) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    return 0;
}
