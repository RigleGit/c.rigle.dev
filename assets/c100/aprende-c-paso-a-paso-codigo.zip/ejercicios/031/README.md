# Ejercicio 31

Fuente: 035-ejercicio-31-invertir-el-orden-de-un-array.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
