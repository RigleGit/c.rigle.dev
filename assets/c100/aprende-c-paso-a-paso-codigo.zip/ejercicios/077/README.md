# Ejercicio 77

Fuente: 081-ejercicio-77-escribir-registros-en-un-archivo-binario.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
