#include <stdio.h>

typedef struct {
    int codigo;
    float precio;
} Producto;

int main(void) {
    Producto lista[] = {
        {101, 12.99},
        {102, 8.50},
        {103, 15.75}
    };
    size_t cantidad = sizeof lista / sizeof lista[0];

    FILE *archivo = fopen("productos.dat", "wb");
    if (archivo == NULL) {
        perror("No se pudo abrir el archivo");
        return 1;
    }

    size_t escritos = fwrite(lista, sizeof lista[0], cantidad, archivo);
    int error = escritos != cantidad;
    if (fclose(archivo) == EOF) error = 1;
    if (error) {
        fputs("No se pudieron guardar todos los productos.\n", stderr);
        return 1;
    }
    puts("Productos guardados correctamente en binario.");
    return 0;
}
