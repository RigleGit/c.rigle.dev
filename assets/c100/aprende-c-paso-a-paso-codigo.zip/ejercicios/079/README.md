# Ejercicio 79

Fuente: 083-ejercicio-79-constantes-de-preprocesador.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
