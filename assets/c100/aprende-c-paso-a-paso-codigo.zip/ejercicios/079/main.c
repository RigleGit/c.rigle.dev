#include <stdio.h>

// Definición de la constante TAMANIO mediante #define
#define TAMANIO 5

int main(void) {
    // Creación del array con tamaño definido por la constante
    int numeros[TAMANIO];

    // Inicialización del array con múltiplos de 10
    for (int i = 0; i < TAMANIO; i++) {
        numeros[i] = (i + 1) * 10;
    }

    // Mostrar el contenido del array
    printf("Contenido del array:\n");
    for (int i = 0; i < TAMANIO; i++) {
        printf("numeros[%d] = %d\n", i, numeros[i]);
    }

    return 0;
}
