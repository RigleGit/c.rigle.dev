# Ejercicio 53

Fuente: 057-ejercicio-53-redimensionar-un-array-din-amicamente-realloc.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
