#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int *datos = NULL;
    int capacidad = 10;    // Capacidad inicial del array
    int cantidad = 0;      // Número de elementos almacenados
    int entrada;

    // Reserva inicial de memoria para 'capacidad' enteros
    datos = (int *)malloc(capacidad * sizeof(int));
    if (datos == NULL) {
        printf("Error al reservar memoria inicial.\n");
        return 1;
    }

    printf("Introduce números (termina con -1):\n");

    while (1) {
        int lectura = scanf("%d", &entrada);
        if (lectura == EOF) {
            if (ferror(stdin)) {
                fputs("Error de lectura.\n", stderr);
                free(datos);
                return 1;
            }
            break;
        }
        if (lectura != 1) { free(datos); return 1; }
        if (entrada == -1) {
            break;
        }

        // Si el array está lleno, ampliar su capacidad en bloques de 10
        if (cantidad == capacidad) {
            if (capacidad >= 1000) {
                free(datos);
                return 1;
            }
            capacidad += 10;
            int *nuevo = (int *)realloc(datos, capacidad * sizeof(int));
            if (nuevo == NULL) {
                printf("Error al redimensionar el array.\n");
                free(datos);
                return 1;
            }
            datos = nuevo;
        }

        datos[cantidad++] = entrada;
    }

    printf("\nHas introducido %d números:\n", cantidad);
    for (int i = 0; i < cantidad; i++) {
        printf("%d ", datos[i]);
    }
    printf("\n");

    // Liberar la memoria y evitar punteros colgantes
    free(datos);
    datos = NULL;

    return 0;
}
