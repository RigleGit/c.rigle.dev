#include <stdio.h>
#include <math.h>

int main(void) {
    double num1, num2, resultado;
    char operador;

    // Solicitar al usuario que introduzca una operación
    printf("Introduce una operación (ejemplo: 4.5 * 2): ");
    if (scanf("%lf %c %lf", &num1, &operador, &num2) != 3 ||
        !isfinite(num1) || !isfinite(num2)) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Evaluar el operador con switch
    switch (operador) {
        case '+':
            resultado = num1 + num2;
            break;
        case '-':
            resultado = num1 - num2;
            break;
        case '*':
            resultado = num1 * num2;
            break;
        case '/':
            if (num2 == 0.0) {
                fputs("Error: división por cero.\n", stderr);
                return 1;
            }
            resultado = num1 / num2;
            break;
        default:
            fputs("Operador no válido.\n", stderr);
            return 1;
    }

    if (!isfinite(resultado)) {
        fputs("Resultado no representable como double finito.\n",
              stderr);
        return 1;
    }
    printf("Resultado: %.2f\n", resultado);

    return 0;
}
