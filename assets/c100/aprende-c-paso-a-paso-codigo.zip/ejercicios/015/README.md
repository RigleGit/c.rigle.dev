# Ejercicio 15

Fuente: 019-ejercicio-15-calculadora-b-asica.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
