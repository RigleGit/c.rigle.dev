# Ejercicio 78

Fuente: 082-ejercicio-78-leer-registros-de-archivo-binario.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
