#include <stdio.h>

typedef struct {
    int codigo;
    float precio;
} Producto;

int main(void) {
    FILE *archivo = fopen("productos.dat", "rb");
    if (archivo == NULL) {
        perror("No se pudo abrir el archivo");
        return 1;
    }

    printf("Productos leídos desde el archivo:\n");
    int error = 0;
    Producto producto;
    for (;;) {
        size_t bytes = fread(&producto, 1, sizeof producto, archivo);
        if (bytes != sizeof producto) {
            if (ferror(archivo)) {
                fputs("Error al leer los productos.\n", stderr);
                error = 1;
            } else if (bytes != 0) {
                fputs("El archivo termina con un registro incompleto.\n", stderr);
                error = 1;
            }
            break;
        }
        if (printf("Código: %d, Precio: %.2f\n",
                   producto.codigo, producto.precio) < 0) {
            error = 1;
            break;
        }
    }
    if (fclose(archivo) == EOF) error = 1;
    if (fflush(stdout) == EOF) error = 1;
    if (error) {
        fputs("No se pudo completar la lectura, salida o cierre.\n", stderr);
        return 1;
    }
    return 0;
}
