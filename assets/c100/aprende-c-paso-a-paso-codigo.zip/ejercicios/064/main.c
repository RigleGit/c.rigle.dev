#include <stdio.h>
#include <stdlib.h>

// Definición del nodo de la lista enlazada
typedef struct Nodo {
    int valor;
    struct Nodo *siguiente;
} Nodo;

// Inserta un nodo al final de la lista
void insertarFinal(Nodo **cabeza, int valor) {
    Nodo *nuevo = (Nodo *)malloc(sizeof(Nodo));
    if (nuevo == NULL) {
        fputs("Error al reservar memoria.\n", stderr);
        exit(EXIT_FAILURE);
    }
    nuevo->valor = valor;
    nuevo->siguiente = NULL;

    if (*cabeza == NULL) {
        *cabeza = nuevo;
    } else {
        Nodo *temp = *cabeza;
        while (temp->siguiente != NULL) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevo;
    }
}

// Recorre e imprime la lista
void imprimirLista(Nodo *cabeza) {
    while (cabeza != NULL) {
        printf("%d -> ", cabeza->valor);
        cabeza = cabeza->siguiente;
    }
    printf("NULL\n");
}

// Elimina el primer nodo que contenga el valor dado
void eliminarNodo(Nodo **cabeza, int valor) {
    Nodo *actual = *cabeza;
    Nodo *anterior = NULL;

    while (actual != NULL) {
        if (actual->valor == valor) {
            if (anterior == NULL) {
                // El nodo a eliminar es la cabeza
                *cabeza = actual->siguiente;
            } else {
                // Reenlazar para saltarse el nodo actual
                anterior->siguiente = actual->siguiente;
            }
            free(actual);
            printf("Nodo con valor %d eliminado.\n", valor);
            return;
        }
        anterior = actual;
        actual = actual->siguiente;
    }

    printf("Valor %d no encontrado en la lista.\n", valor);
}

int main(void) {
    Nodo *lista = NULL;

    insertarFinal(&lista, 10);
    insertarFinal(&lista, 20);
    insertarFinal(&lista, 30);
    insertarFinal(&lista, 40);

    printf("Lista original:\n");
    imprimirLista(lista);

    eliminarNodo(&lista, 30);
    imprimirLista(lista);

    eliminarNodo(&lista, 10); // eliminar cabeza
    imprimirLista(lista);

    eliminarNodo(&lista, 99); // valor inexistente
    imprimirLista(lista);

    // Liberar la lista restante
    while (lista != NULL) {
        Nodo *sig = lista->siguiente;
        free(lista);
        lista = sig;
    }

    return 0;
}
