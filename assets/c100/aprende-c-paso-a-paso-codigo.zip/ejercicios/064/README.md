# Ejercicio 64

Fuente: 068-ejercicio-64-eliminar-un-nodo-de-la-lista-enlazada.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
