#include <stdio.h>

// Descomenta la siguiente línea para activar el modo debug directamente en el código
// #define DEBUG

void procesarDatos(int x) {
    #ifdef DEBUG
    printf("[DEBUG] Entrando en procesarDatos con x = %d\n", x);
    #endif

    int resultado = x * 2 + 3;

    #ifdef DEBUG
    printf("[DEBUG] Resultado intermedio = %d\n", resultado);
    #endif

    printf("Resultado final: %d\n", resultado);
}

int main(void) {
    int dato = 5;

    #ifdef DEBUG
    printf("[DEBUG] Iniciando programa\n");
    #endif

    procesarDatos(dato);

    #ifdef DEBUG
    printf("[DEBUG] Finalizando programa\n");
    #endif

    return 0;
}
