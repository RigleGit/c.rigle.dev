# Ejercicio 81

Fuente: 085-ejercicio-81-cifrado-c-esar.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
