# Ejercicio 63

Fuente: 067-ejercicio-63-lista-enlazada-simple.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
