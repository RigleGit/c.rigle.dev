#include <stdio.h>
#include <stdlib.h>

// Definición de la estructura Nodo con typedef
typedef struct Nodo {
    int valor;              // Valor entero almacenado en el nodo
    struct Nodo* siguiente; // Puntero al siguiente nodo
} Nodo;

// Función para insertar un nuevo nodo al final de la lista
void insertarFinal(Nodo** cabeza, int valor) {
    Nodo* nuevo = (Nodo*)malloc(sizeof(Nodo));
    if (nuevo == NULL) {
        fputs("Error al reservar memoria.\n", stderr);
        exit(EXIT_FAILURE);
    }
    nuevo->valor = valor;
    nuevo->siguiente = NULL;

    if (*cabeza == NULL) {
        // La lista está vacía, el nuevo nodo será la cabeza
        *cabeza = nuevo;
    } else {
        // Recorre hasta el último nodo
        Nodo* temp = *cabeza;
        while (temp->siguiente != NULL) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevo;
    }
}

// Función para recorrer e imprimir todos los valores de la lista
void imprimirLista(Nodo* cabeza) {
    Nodo* temp = cabeza;
    while (temp != NULL) {
        printf("%d -> ", temp->valor);
        temp = temp->siguiente;
    }
    printf("NULL\n");
}

int main(void) {
    Nodo* lista = NULL;

    insertarFinal(&lista, 10);
    insertarFinal(&lista, 20);
    insertarFinal(&lista, 30);

    imprimirLista(lista);

    // Liberar memoria para evitar fugas
    Nodo* actual = lista;
    while (actual != NULL) {
        Nodo* siguiente = actual->siguiente;
        free(actual);
        actual = siguiente;
    }

    return 0;
}
