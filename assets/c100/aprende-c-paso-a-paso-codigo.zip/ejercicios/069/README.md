# Ejercicio 69

Fuente: 073-ejercicio-69-altura-de-un-arbol-binario.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
