#include <stdio.h>
#include <stdlib.h>

// Definición de la estructura del nodo del árbol binario
typedef struct NodoArbol {
    int valor;
    struct NodoArbol* izq;
    struct NodoArbol* der;
} NodoArbol;

// Función para insertar un valor en el árbol binario de búsqueda
NodoArbol* insertar(NodoArbol* raiz, int valor) {
    if (raiz == NULL) {
        NodoArbol* nuevo = malloc(sizeof(NodoArbol));
        if (nuevo == NULL) {
            fputs("No se pudo reservar el nodo.\n", stderr);
            exit(EXIT_FAILURE);
        }
        nuevo->valor = valor;
        nuevo->izq = nuevo->der = NULL;
        return nuevo;
    }
    if (valor < raiz->valor) {
        raiz->izq = insertar(raiz->izq, valor);
    } else if (valor > raiz->valor) {
        raiz->der = insertar(raiz->der, valor);
    }
    return raiz;
}

// Función recursiva para calcular la altura del árbol binario
int altura(NodoArbol* raiz) {
    if (raiz == NULL)
        return 0;
    int altIzq = altura(raiz->izq);
    int altDer = altura(raiz->der);
    return (altIzq > altDer ? altIzq : altDer) + 1;
}

// Función para liberar la memoria asignada al árbol
void liberarArbol(NodoArbol* raiz) {
    if (raiz) {
        liberarArbol(raiz->izq);
        liberarArbol(raiz->der);
        free(raiz);
    }
}

int main(void) {
    NodoArbol* arbol = NULL;
    int valores[] = {8, 3, 10, 1, 6, 14, 4, 7, 13};
    int n = sizeof(valores) / sizeof(valores[0]);

    for (int i = 0; i < n; i++) {
        arbol = insertar(arbol, valores[i]);
    }

    printf("La altura del árbol es: %d\n", altura(arbol));

    liberarArbol(arbol);
    return 0;
}
