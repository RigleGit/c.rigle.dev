# Ejercicio 92

Fuente: 096-ejercicio-92-servidor-multicliente.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
