#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <errno.h>
#include <signal.h>

#define PUERTO 8080
#define BUFFER 1024

static void *atender_cliente(void *arg) {
    int cliente = *(int *)arg;
    free(arg);
    char buffer[BUFFER];
    for (;;) {
        ssize_t leidos = recv(cliente, buffer, sizeof(buffer), 0);
        if (leidos < 0 && errno == EINTR) continue;
        if (leidos <= 0) {
            if (leidos < 0) perror("recv");
            break;
        }
        ssize_t enviados = 0;
        while (enviados < leidos) {
            ssize_t n = send(cliente, buffer + enviados,
                             (size_t)(leidos - enviados), 0);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) {
                fputs("No se pudo completar el eco.\n", stderr);
                close(cliente);
                return NULL;
            }
            enviados += n;
        }
    }
    close(cliente);
    return NULL;
}

int main(void) {
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
        perror("signal");
        return 1;
    }
    int servidor = socket(AF_INET, SOCK_STREAM, 0);
    if (servidor < 0) {
        perror("socket");
        return 1;
    }
    int opcion = 1;
    if (setsockopt(servidor, SOL_SOCKET, SO_REUSEADDR,
                   &opcion, sizeof(opcion)) < 0) {
        perror("setsockopt");
        close(servidor);
        return 1;
    }
    struct sockaddr_in direccion = {0};
    direccion.sin_family = AF_INET;
    direccion.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    direccion.sin_port = htons(PUERTO);
    if (bind(servidor, (struct sockaddr *)&direccion,
             sizeof(direccion)) < 0 || listen(servidor, 10) < 0) {
        perror("bind/listen");
        close(servidor);
        return 1;
    }
    pthread_attr_t atributos;
    int error = pthread_attr_init(&atributos);
    if (error != 0) {
        fprintf(stderr, "pthread_attr_init: %s\n", strerror(error));
        close(servidor);
        return 1;
    }
    error = pthread_attr_setdetachstate(&atributos,
                                       PTHREAD_CREATE_DETACHED);
    if (error != 0) {
        fprintf(stderr, "setdetachstate: %s\n", strerror(error));
        pthread_attr_destroy(&atributos);
        close(servidor);
        return 1;
    }
    printf("Servidor local escuchando en puerto %d...\n", PUERTO);
    for (;;) {
        int cliente = accept(servidor, NULL, NULL);
        if (cliente < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            break;
        }
        int *argumento = malloc(sizeof(*argumento));
        if (argumento == NULL) {
            fputs("No se pudo reservar el argumento del hilo.\n", stderr);
            close(cliente);
            break;
        }
        *argumento = cliente;
        pthread_t hilo;
        error = pthread_create(&hilo, &atributos,
                               atender_cliente, argumento);
        if (error != 0) {
            fprintf(stderr, "pthread_create: %s\n", strerror(error));
            close(cliente);
            free(argumento);
        }
    }
    pthread_attr_destroy(&atributos);
    close(servidor);
    return 1;
}
