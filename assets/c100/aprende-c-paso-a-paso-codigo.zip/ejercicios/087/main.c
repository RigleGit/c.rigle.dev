#include <stdio.h>
#include <pthread.h>

#include <stdlib.h>
#include <string.h>

static void comprobar_pthread(int error, const char *operacion) {
    if (error != 0) {
        fprintf(stderr, "%s: %s\n", operacion, strerror(error));
        exit(EXIT_FAILURE);
    }
}

#define NUM_INCREMENTOS 100000

int contador = 0;                                  // Recurso compartido
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER; // Mutex global

// Función que ejecuta cada hilo: incrementa de manera segura
void* incrementar(void* arg) {
    (void)arg;
    for (int i = 0; i < NUM_INCREMENTOS; i++) {
        comprobar_pthread(pthread_mutex_lock(&mutex), "pthread_mutex_lock");   // Inicio de sección crítica
        contador++;                   // Acceso protegido
        comprobar_pthread(pthread_mutex_unlock(&mutex), "pthread_mutex_unlock"); // Fin de sección crítica
    }
    return NULL;
}

int main(void) {
    pthread_t hilo1, hilo2;

    // Crear los hilos que incrementan el contador
    comprobar_pthread(pthread_create(&hilo1, NULL, incrementar, NULL), "pthread_create");
    comprobar_pthread(pthread_create(&hilo2, NULL, incrementar, NULL), "pthread_create");

    // Esperar a que ambos hilos terminen
    comprobar_pthread(pthread_join(hilo1, NULL), "pthread_join");
    comprobar_pthread(pthread_join(hilo2, NULL), "pthread_join");

    // Mostrar resultados
    printf("Valor esperado: %d\n", NUM_INCREMENTOS * 2);
    printf("Valor real: %d\n", contador);

    // Destruir el mutex
    comprobar_pthread(pthread_mutex_destroy(&mutex), "pthread_mutex_destroy");
    return 0;
}
