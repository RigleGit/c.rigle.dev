# Ejercicio 87

Fuente: 091-ejercicio-87-uso-de-mutex-para-sincronizar.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
