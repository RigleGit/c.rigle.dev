# Ejercicio 84

Fuente: 088-ejercicio-84-primer-hilo.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
