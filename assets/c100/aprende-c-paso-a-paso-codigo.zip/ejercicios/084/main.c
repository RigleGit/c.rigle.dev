#include <stdio.h>
#include <pthread.h>
#include <string.h>

// Función que ejecutará el hilo
void* funcionDelHilo(void* arg) {
    (void)arg;
    printf("Hola desde el hilo hijo.\n");
    return NULL;
}

int main(void) {
    pthread_t hilo;

    // Crear el hilo
    int error = pthread_create(&hilo, NULL, funcionDelHilo, NULL);
    if (error != 0) {
        fprintf(stderr, "Error al crear el hilo: %s\n", strerror(error));
        return 1;
    }

    printf("Hilo principal esperando al hilo hijo...\n");

    // Esperar a que el hilo termine
    error = pthread_join(hilo, NULL);
    if (error != 0) {
        fprintf(stderr, "Error al esperar el hilo: %s\n", strerror(error));
        return 1;
    }

    printf("Hilo hijo ha terminado. Fin del programa.\n");
    return 0;
}
