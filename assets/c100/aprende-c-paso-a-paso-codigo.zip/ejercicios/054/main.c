#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    char cadena1[100];
    char cadena2[100];

    // Leer la primera cadena
    printf("Introduce la primera cadena: ");
    if (fgets(cadena1, sizeof(cadena1), stdin) == NULL) return 1;
    size_t longitud1 = strcspn(cadena1, "\n");
    if (longitud1 > 98 ||
        (cadena1[longitud1] != '\n' && !feof(stdin))) {
        fputs("Primera cadena demasiado larga.\n", stderr);
        return 1;
    }
    cadena1[longitud1] = '\0'; // Eliminar el salto de línea

    // Leer la segunda cadena
    printf("Introduce la segunda cadena: ");
    if (fgets(cadena2, sizeof(cadena2), stdin) == NULL) return 1;
    size_t longitud2 = strcspn(cadena2, "\n");
    if (longitud2 > 98 ||
        (cadena2[longitud2] != '\n' && !feof(stdin))) {
        fputs("Segunda cadena demasiado larga.\n", stderr);
        return 1;
    }
    cadena2[longitud2] = '\0'; // Eliminar el salto de línea

    // Calcular la longitud total necesaria para la nueva cadena
    size_t longitud_total = strlen(cadena1) + strlen(cadena2) + 1;

    // Reservar memoria dinámicamente
    char *resultado = (char *)malloc(longitud_total * sizeof(char));
    if (resultado == NULL) {
        printf("Error al reservar memoria.\n");
        return 1;
    }

    // Copiar y concatenar las cadenas
    strcpy(resultado, cadena1);
    strcat(resultado, cadena2);

    // Mostrar el resultado
    printf("Cadena concatenada: %s\n", resultado);

    // Liberar la memoria reservada
    free(resultado);
    resultado = NULL;

    return 0;
}
