# Ejercicio 54

Fuente: 058-ejercicio-54-concatenar-dos-cadenas-con-malloc.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
