#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <string.h>
#include "contacto.h"
#include "persistencia.h"

static void menu(void) {
    puts("\n--- Agenda de Contactos ---");
    puts("1. Añadir contacto\n2. Buscar contacto\n3. Eliminar contacto");
    puts("4. Listar contactos\n5. Guardar\n6. Cargar");
    puts("7. Salir\n8. Editar teléfono y email");
}

static int leerOpcion(void) {
    char linea[32], *fin;
    printf("Opción: ");
    if (!fgets(linea, sizeof linea, stdin)) return 7;
    if (!strchr(linea, '\n') && !feof(stdin)) {
        int c;
        while ((c = getchar()) != '\n' && c != EOF) {}
        return 0;
    }
    errno = 0;
    long opcion = strtol(linea, &fin, 10);
    if (fin == linea || errno == ERANGE) return 0;
    while (isspace((unsigned char)*fin)) fin++;
    if (*fin != '\0' || opcion < 1 || opcion > 8) return 0;
    return (int)opcion;
}

int main(void) {
    Nodo *agenda = NULL;
    int opcion;
    do {
        menu();
        opcion = leerOpcion();
        switch (opcion) {
            case 1: agregarContacto(&agenda); break;
            case 2: buscarContacto(agenda); break;
            case 3: eliminarContacto(&agenda); break;
            case 4: listarContactos(agenda); break;
            case 5: guardarContactos(agenda); break;
            case 6: cargarContactos(&agenda); break;
            case 7: puts("Saliendo..."); break;
            case 8: editarContacto(agenda); break;
            default: puts("Entrada inválida."); break;
        }
    } while (opcion != 7);
    liberarLista(agenda);
    return 0;
}
