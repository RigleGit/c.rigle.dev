#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persistencia.h"

void guardarContactos(const Nodo *inicio) {
    FILE *f = fopen("agenda.txt", "w");
    if (!f) {
        puts("No se pudo abrir el archivo para guardar.");
        return;
    }
    int error = 0;
    for (; inicio; inicio = inicio->siguiente) {
        if (fprintf(f, "%s|%s|%s\n", inicio->contacto.nombre,
                    inicio->contacto.telefono,
                    inicio->contacto.email) < 0) {
            error = 1;
            break;
        }
    }
    if (fclose(f) == EOF) error = 1;
    puts(error ? "Error al guardar; el archivo puede estar incompleto."
               : "Contactos guardados correctamente.");
}

static int separarCampos(char *linea, Contacto *contacto) {
    linea[strcspn(linea, "\r\n")] = '\0';
    char *primero = strchr(linea, '|');
    if (!primero) return 0;
    *primero++ = '\0';
    char *segundo = strchr(primero, '|');
    if (!segundo) return 0;
    *segundo++ = '\0';
    if (strchr(segundo, '|') || linea[0] == '\0' ||
        strlen(linea) >= TAM || strlen(primero) >= TAM ||
        strlen(segundo) >= TAM) return 0;
    strcpy(contacto->nombre, linea);
    strcpy(contacto->telefono, primero);
    strcpy(contacto->email, segundo);
    return 1;
}

void cargarContactos(Nodo **inicio) {
    FILE *f = fopen("agenda.txt", "r");
    if (!f) {
        puts("No se pudo abrir agenda.txt.");
        return;
    }
    Nodo *nueva = NULL;
    Nodo **cola = &nueva;
    char linea[3 * TAM + 2];
    int error = 0;
    while (fgets(linea, sizeof linea, f)) {
        Contacto c;
        if ((!strchr(linea, '\n') && !feof(f)) ||
            !separarCampos(linea, &c)) {
            error = 1;
            break;
        }
        Nodo *nuevo = malloc(sizeof *nuevo);
        if (!nuevo) {
            error = 1;
            break;
        }
        nuevo->contacto = c;
        nuevo->siguiente = NULL;
        *cola = nuevo;
        cola = &nuevo->siguiente;
    }
    if (ferror(f)) error = 1;
    if (fclose(f) == EOF) error = 1;
    if (error) {
        liberarLista(nueva);
        puts("Carga cancelada; se conserva la agenda anterior.");
        return;
    }
    liberarLista(*inicio);
    *inicio = nueva;
    puts("Contactos cargados desde archivo.");
}
