# Ejercicio 99

Fuente: 103-ejercicio-99-agenda-de-contactos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
