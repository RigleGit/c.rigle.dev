#ifndef PERSISTENCIA_H
#define PERSISTENCIA_H
#include "contacto.h"
void guardarContactos(const Nodo *inicio);
void cargarContactos(Nodo **inicio);
#endif
