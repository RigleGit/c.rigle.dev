#ifndef CONTACTO_H
#define CONTACTO_H
#define TAM 100

typedef struct {
    char nombre[TAM];
    char telefono[TAM];
    char email[TAM];
} Contacto;

typedef struct Nodo {
    Contacto contacto;
    struct Nodo *siguiente;
} Nodo;

void agregarContacto(Nodo **inicio);
void listarContactos(const Nodo *inicio);
void buscarContacto(const Nodo *inicio);
void eliminarContacto(Nodo **inicio);
void editarContacto(Nodo *inicio);
void liberarLista(Nodo *inicio);
#endif
