#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contacto.h"

static int leerCampo(const char *mensaje, char salida[TAM]) {
    printf("%s", mensaje);
    if (!fgets(salida, TAM, stdin)) return 0;
    if (!strchr(salida, '\n')) {
        int c = getchar();
        if (c == '\r') c = getchar();
        if (c != '\n' && c != EOF) {
            while ((c = getchar()) != '\n' && c != EOF) {}
            puts("Campo demasiado largo.");
            return 0;
        }
        if (c == EOF && ferror(stdin)) return 0;
    }
    salida[strcspn(salida, "\r\n")] = '\0';
    if (strchr(salida, '|')) {
        puts("El campo no puede contener |.");
        return 0;
    }
    return 1;
}

void agregarContacto(Nodo **inicio) {
    Contacto c;
    if (!leerCampo("Nombre: ", c.nombre) || c.nombre[0] == '\0' ||
        !leerCampo("Teléfono: ", c.telefono) ||
        !leerCampo("Email: ", c.email)) {
        puts("No se añadió el contacto.");
        return;
    }
    Nodo *nuevo = malloc(sizeof *nuevo);
    if (!nuevo) {
        puts("Error al reservar memoria.");
        return;
    }
    nuevo->contacto = c;
    nuevo->siguiente = *inicio;
    *inicio = nuevo;
    puts("Contacto añadido correctamente.");
}

void listarContactos(const Nodo *inicio) {
    if (!inicio) {
        puts("Agenda vacía.");
        return;
    }
    size_t i = 1;
    for (; inicio; inicio = inicio->siguiente) {
        printf("\nContacto #%zu:\n", i++);
        printf(" Nombre: %s\n", inicio->contacto.nombre);
        printf(" Teléfono: %s\n", inicio->contacto.telefono);
        printf(" Email: %s\n", inicio->contacto.email);
    }
}

void buscarContacto(const Nodo *inicio) {
    char nombre[TAM];
    if (!leerCampo("Nombre a buscar: ", nombre)) return;
    for (; inicio; inicio = inicio->siguiente) {
        if (strcmp(inicio->contacto.nombre, nombre) == 0) {
            printf("Encontrado: %s\n", inicio->contacto.nombre);
            printf(" Teléfono: %s\n", inicio->contacto.telefono);
            printf(" Email: %s\n", inicio->contacto.email);
            return;
        }
    }
    puts("Contacto no encontrado.");
}

void eliminarContacto(Nodo **inicio) {
    char nombre[TAM];
    if (!leerCampo("Nombre a eliminar: ", nombre)) return;
    Nodo **enlace = inicio;
    while (*enlace) {
        Nodo *actual = *enlace;
        if (strcmp(actual->contacto.nombre, nombre) == 0) {
            *enlace = actual->siguiente;
            free(actual);
            puts("Contacto eliminado.");
            return;
        }
        enlace = &actual->siguiente;
    }
    puts("Contacto no encontrado.");
}

void editarContacto(Nodo *inicio) {
    char nombre[TAM], telefono[TAM], email[TAM];
    if (!leerCampo("Nombre a editar: ", nombre)) return;
    for (; inicio; inicio = inicio->siguiente) {
        if (strcmp(inicio->contacto.nombre, nombre) == 0) {
            if (!leerCampo("Nuevo teléfono: ", telefono) ||
                !leerCampo("Nuevo email: ", email)) return;
            strcpy(inicio->contacto.telefono, telefono);
            strcpy(inicio->contacto.email, email);
            puts("Contacto actualizado.");
            return;
        }
    }
    puts("Contacto no encontrado.");
}

void liberarLista(Nodo *inicio) {
    while (inicio) {
        Nodo *siguiente = inicio->siguiente;
        free(inicio);
        inicio = siguiente;
    }
}
