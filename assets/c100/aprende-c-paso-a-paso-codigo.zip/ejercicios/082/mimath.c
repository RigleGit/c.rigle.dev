#include "mimath.h"

// Implementación de la suma
int suma(int a, int b) {
    return a + b;
}

// Implementación de la resta
int resta(int a, int b) {
    return a - b;
}

// Implementación de la potencia
int potencia(int base, int exponente) {
    int resultado = 1;
    for (int i = 0; i < exponente; i++) {
        resultado *= base;
    }
    return resultado;
}
