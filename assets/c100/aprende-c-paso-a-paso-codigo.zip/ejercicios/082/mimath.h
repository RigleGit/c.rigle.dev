#ifndef MIMATH_H
#define MIMATH_H

// Declaraciones de funciones matemáticas
int suma(int a, int b);
int resta(int a, int b);
int potencia(int base, int exponente);

#endif // MIMATH_H
