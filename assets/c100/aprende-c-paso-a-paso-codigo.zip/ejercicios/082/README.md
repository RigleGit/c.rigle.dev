# Ejercicio 82

Fuente: 086-ejercicio-82-m-odulos-y-headers.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
