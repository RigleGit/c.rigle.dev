#include <stdio.h>
#include "mimath.h"

int main(void) {
    int a = 3, b = 4;
    printf("Suma: %d\n", suma(a, b));
    printf("Resta: %d\n", resta(a, b));
    printf("Potencia: %d\n", potencia(a, b));
    return 0;
}
