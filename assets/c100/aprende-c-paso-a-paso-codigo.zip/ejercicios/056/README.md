# Ejercicio 56

Fuente: 060-ejercicio-56-arreglo-din-amico-de-cadenas.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
