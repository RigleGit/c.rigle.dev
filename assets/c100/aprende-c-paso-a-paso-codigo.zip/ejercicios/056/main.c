#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    int n, creados = 0, estado = 1;
    printf("¿Cuántos nombres vas a introducir?: ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 100) return 1;
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
    if (c == EOF) return 1;

    char **nombres = malloc((size_t)n * sizeof(*nombres));
    if (nombres == NULL) {
        fputs("No se pudo reservar el array de punteros.\n", stderr);
        return 1;
    }
    for (int i = 0; i < n; ++i) {
        char buffer[100];
        printf("Nombre %d: ", i + 1);
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            fputs("Falta un nombre.\n", stderr);
            goto limpieza;
        }
        size_t longitud = strcspn(buffer, "\n");
        if (longitud > 98 ||
            (buffer[longitud] != '\n' && !feof(stdin))) {
            fputs("Nombre demasiado largo.\n", stderr);
            goto limpieza;
        }
        buffer[longitud] = '\0';
        nombres[i] = malloc(longitud + 1);
        if (nombres[i] == NULL) {
            fputs("No se pudo reservar un nombre.\n", stderr);
            goto limpieza;
        }
        strcpy(nombres[i], buffer);
        ++creados;
    }
    printf("Nombres introducidos:\n");
    for (int i = 0; i < n; ++i) puts(nombres[i]);
    estado = 0;

limpieza:
    for (int i = 0; i < creados; ++i) free(nombres[i]);
    free(nombres);
    return estado;
}
