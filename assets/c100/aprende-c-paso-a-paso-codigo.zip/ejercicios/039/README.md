# Ejercicio 39

Fuente: 043-ejercicio-39-contar-vocales-en-una-cadena.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
