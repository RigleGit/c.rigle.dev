#include <stdio.h>

int main(void) {
    char cadena[100];
    int i = 0;
    int contador = 0;

    printf("Introduce una cadena: ");
    if (fgets(cadena, sizeof(cadena), stdin) == NULL) {
        return 1;
    }

    // Recorremos la cadena hasta el carácter nulo '\0'
    while (cadena[i] != '\0') {
        char c = cadena[i];

        // Comprobamos si el carácter es una vocal (mayúscula o minúscula)
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
            contador++;
        }
        i++;
    }

    // Comprobar que se ha leído la línea completa
    if (i == 0 || cadena[i - 1] != '\n') {
        int siguiente = getchar();
        if (siguiente != '\n' && (siguiente != EOF || ferror(stdin))) {
            fputs("Línea demasiado larga o error de lectura.\n",
                  stderr);
            return 1;
        }
    }

    printf("La cadena contiene %d vocales.\n", contador);

    return 0;
}
