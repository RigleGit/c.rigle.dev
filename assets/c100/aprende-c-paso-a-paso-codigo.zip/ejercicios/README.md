# Código de Aprende C paso a paso

Carpetas 001 a 100. 82 y 99 incluyen todos sus módulos; 91, emisor y receptor. 94, 95 y 97 entregan la versión corregida como principal.

Compila con cc -std=c17 -Wall -Wextra -Wpedantic, añadiendo -lm y -pthread. Ejemplo: cc -std=c17 099/main.c 099/contacto.c 099/persistencia.c -o agenda

El ejercicio 86 contiene una carrera deliberada. Los originales de seguridad se incluyen como texto de análisis y no se compilan por defecto.
