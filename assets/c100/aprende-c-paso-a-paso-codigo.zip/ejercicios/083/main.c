#include <stdio.h>      // Para printf
#include <math.h>       // Para sqrt
#include <assert.h>     // Para assert

// Función que calcula la raíz cuadrada de un número no negativo
double raizCuadrada(double x) {
    // Verifica que el argumento no sea negativo
    assert(x >= 0 && "El argumento no puede ser negativo");
    return sqrt(x);
}

int main(void) {
    double valor1 = 25.0;
    double valor2 = -9.0;

    // Prueba con un valor válido
    printf("Raíz de %.2f: %.2f\n", valor1, raizCuadrada(valor1));

    // Prueba con un valor inválido (provocará fallo si assert está activo)
    printf("Raíz de %.2f: %.2f\n", valor2, raizCuadrada(valor2));

    return 0;
}
