# Ejercicio 83

Fuente: 087-ejercicio-83-uso-de-la-macro-assert.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
