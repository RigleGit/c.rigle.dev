# Ejercicio 16

Fuente: 020-ejercicio-16-factorial-de-un-n-umero-bucle-for.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
