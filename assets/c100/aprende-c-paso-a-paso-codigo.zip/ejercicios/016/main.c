#include <stdio.h>

int main(void) {
    int n;
    unsigned long long factorial = 1;

    printf("Introduce un entero entre 0 y 20: ");
    if (scanf("%d", &n) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (n < 0 || n > 20) {
        fputs("Este ejemplo admite números entre 0 y 20.\n", stderr);
        return 1;
    } else {
        for (int i = 1; i <= n; ++i) {
            factorial *= i;
        }
        printf("El factorial de %d es %llu\n", n, factorial);
    }

    return 0;
}
