#include <stdio.h>

// Función que implementa la búsqueda binaria iterativa
int busquedaBinaria(int arr[], int n, int clave) {
    int inicio = 0;
    int fin = n - 1;

    while (inicio <= fin) {
        int medio = inicio + (fin - inicio) / 2;

        if (arr[medio] == clave)
            return medio;  // Elemento encontrado, devolver índice
        else if (arr[medio] < clave)
            inicio = medio + 1;  // Buscar en la mitad derecha
        else
            fin = medio - 1;     // Buscar en la mitad izquierda
    }

    return -1;  // Elemento no encontrado
}

// Función para imprimir los elementos del array
void imprimirArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main(void) {
    int arr[] = {1, 3, 5, 7, 9, 11, 13};
    int n = sizeof(arr) / sizeof(arr[0]);
    int clave = 7;

    printf("Array:\n");
    imprimirArray(arr, n);

    int indice = busquedaBinaria(arr, n, clave);

    if (indice != -1)
        printf("Elemento %d encontrado en la posición %d.\n", clave, indice);
    else
        printf("Elemento %d no encontrado.\n", clave);

    return 0;
}
