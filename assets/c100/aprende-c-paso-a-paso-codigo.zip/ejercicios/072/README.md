# Ejercicio 72

Fuente: 076-ejercicio-72-b-usqueda-binaria-en-array-ordenado.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
