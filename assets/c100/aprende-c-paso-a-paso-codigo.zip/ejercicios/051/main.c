#include <stdio.h>
#include <stdlib.h>

int main(void) {
    // Reservar memoria para un entero
    int *ptr = (int *)malloc(sizeof(int));
    if (ptr == NULL) {
        printf("Error al reservar memoria.\n");
        return 1;
    }

    // Asignar un valor al entero reservado
    *ptr = 2025;

    // Imprimir el valor almacenado
    printf("Valor almacenado: %d\n", *ptr);

    // Liberar la memoria y evitar puntero colgante
    free(ptr);
    ptr = NULL;

    return 0;
}
