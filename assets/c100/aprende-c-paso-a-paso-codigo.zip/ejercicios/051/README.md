# Ejercicio 51

Fuente: 055-ejercicio-51-reservar-y-liberar-un-entero-din-amicamente.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
