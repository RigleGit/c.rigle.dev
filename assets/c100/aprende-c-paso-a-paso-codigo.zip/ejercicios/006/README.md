# Ejercicio 6

Fuente: 010-ejercicio-6-c-odigo-ascii-de-un-car-acter.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
