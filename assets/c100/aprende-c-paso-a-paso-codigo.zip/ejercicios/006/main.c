#include <stdio.h>

int main(void) {
    char caracter;

    printf("Introduce un carácter: ");
    scanf("%c", &caracter);

    printf("El código ASCII de '%c' es: %d\n",
           caracter, (int)caracter);

    return 0;
}
