#include <stdio.h>

// Definición de la macro CUADRADO que calcula el cuadrado de un valor
#define CUADRADO(x) ((x) * (x))

// Función que devuelve 1 y muestra un mensaje cuando es llamada
int sumarUno(void) {
    printf("sumarUno() llamado\n");
    return 1;
}

int main(void) {
    int a = 5;

    // Prueba con un valor simple
    printf("CUADRADO(a) = %d\n", CUADRADO(a)); // 25

    // Prueba con una expresión aritmética
    printf("CUADRADO(3 + 1) = %d\n", CUADRADO(3 + 1)); // 16

    // Prueba con una llamada a función (se ejecuta dos veces)
    printf("CUADRADO(sumarUno()) = %d\n", CUADRADO(sumarUno()));

    return 0;
}
