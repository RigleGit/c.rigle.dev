# Ejercicio 80

Fuente: 084-ejercicio-80-programaci-on-de-redes-as-incrona.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
