#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int filas, columnas;

    // Solicitar dimensiones de la matriz
    printf("Introduce el número de filas: ");
    if (scanf("%d", &filas) != 1 || filas < 1 || filas > 100) {
        fputs("Filas: introduce un entero de 1 a 100.\n", stderr);
        return 1;
    }

    printf("Introduce el número de columnas: ");
    if (scanf("%d", &columnas) != 1 || columnas < 1 || columnas > 100) {
        fputs("Columnas: introduce un entero de 1 a 100.\n", stderr);
        return 1;
    }

    // Reserva de memoria para el array de punteros (filas)
    int **matriz = (int **)malloc(filas * sizeof(int *));
    if (matriz == NULL) {
        printf("Error al reservar memoria para filas.\n");
        return 1;
    }

    // Reserva de memoria para cada fila
    for (int i = 0; i < filas; i++) {
        matriz[i] = (int *)malloc(columnas * sizeof(int));
        if (matriz[i] == NULL) {
            printf("Error al reservar memoria para la fila %d.\n", i);
            // Liberar memoria ya reservada antes de salir
            for (int j = 0; j < i; j++) {
                free(matriz[j]);
            }
            free(matriz);
            return 1;
        }
    }

    // Rellenar la matriz con valores (ejemplo: i * j)
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            matriz[i][j] = i * j;
        }
    }

    // Mostrar la matriz
    printf("Contenido de la matriz:\n");
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }

    // Liberar la memoria reservada
    for (int i = 0; i < filas; i++) {
        free(matriz[i]);
    }
    free(matriz);
    matriz = NULL;

    return 0;
}
