# Ejercicio 55

Fuente: 059-ejercicio-55-matriz-din-amica-2d-reserva-de-doble-puntero.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
