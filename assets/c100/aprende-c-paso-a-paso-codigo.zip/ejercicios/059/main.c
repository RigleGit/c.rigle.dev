#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>

_Static_assert(CHAR_BIT == 8,
               "El ejercicio requiere bytes de ocho bits");

union Datos {
    uint32_t entero;
    unsigned char bytes[sizeof(uint32_t)];
};

int main(void) {
    union Datos d;
    d.entero = UINT32_C(0x12345678);
    printf("Valor entero: 0x%" PRIX32 "\n", d.entero);
    printf("Bytes individuales:\n");
    for (size_t i = 0; i < sizeof(d.bytes); ++i) {
        printf("Byte %zu: 0x%02X\n", i,
               (unsigned int)d.bytes[i]);
    }
    return 0;
}
