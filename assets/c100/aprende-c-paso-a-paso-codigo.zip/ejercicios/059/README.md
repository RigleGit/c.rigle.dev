# Ejercicio 59

Fuente: 063-ejercicio-59-uni-on-para-reinterpretar-datos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
