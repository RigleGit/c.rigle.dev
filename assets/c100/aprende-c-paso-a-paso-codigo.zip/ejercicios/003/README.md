# Ejercicio 3

Fuente: 007-ejercicio-3-entrada-y-salida.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
