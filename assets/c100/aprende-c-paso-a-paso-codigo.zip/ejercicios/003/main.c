#include <stdio.h>

int main(void) {
    float celsius, fahrenheit;

    printf("Introduce la temperatura en grados Celsius: ");
    scanf("%f", &celsius);

    fahrenheit = celsius * 9.0 / 5.0 + 32.0;

    printf("%.1f grados Celsius equivalen a %.1f grados Fahrenheit\n",
           celsius, fahrenheit);

    return 0;
}
