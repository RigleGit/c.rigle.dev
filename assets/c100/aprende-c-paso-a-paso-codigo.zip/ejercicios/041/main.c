#include <stdio.h>

// Leer una línea completa sin almacenar su salto final
int leerLinea(char cadena[], int capacidad) {
    if (fgets(cadena, capacidad, stdin) == NULL) return 0;
    int i = 0;
    while (cadena[i] != '\0' && cadena[i] != '\n') i++;
    if (cadena[i] == '\n') {
        cadena[i] = '\0';
    } else {
        // Si el array se llenó, comprobar el carácter pendiente
        int siguiente = getchar();
        if (siguiente != '\n' &&
            (siguiente != EOF || ferror(stdin))) {
            fputs("Línea demasiado larga o error de lectura.\n", stderr);
            return 0;
        }
    }
    return 1;
}

int main(void) {
    char cadena1[100], cadena2[100];
    int iguales = 1; // Suponemos que son iguales hasta que se demuestre lo contrario
    int i = 0;

    printf("Introduce la primera cadena: ");
    if (!leerLinea(cadena1, sizeof cadena1)) {
        return 1;
    }

    printf("Introduce la segunda cadena: ");
    if (!leerLinea(cadena2, sizeof cadena2)) {
        return 1;
    }

    // Comparar carácter a carácter ambas cadenas
    while (cadena1[i] != '\0' || cadena2[i] != '\0') {
        if (cadena1[i] != cadena2[i]) {
            iguales = 0;
            break;
        }
        i++;
    }

    if (iguales) {
        printf("Las cadenas son iguales.\n");
    } else {
        printf("Las cadenas son diferentes.\n");
    }

    return 0;
}
