# Ejercicio 41

Fuente: 045-ejercicio-41-comparar-dos-cadenas-sin-strcmp.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
