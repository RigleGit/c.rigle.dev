# Ejercicio 32

Fuente: 036-ejercicio-32-suma-y-promedio-de-elementos-del-array.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
