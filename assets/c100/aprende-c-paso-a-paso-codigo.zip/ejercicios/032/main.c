#include <stdio.h>
#include <limits.h>
#define MAX 100

int main(void) {
    int numeros[MAX], n;
    long long suma = 0;
    printf("¿Cuántos números quieres introducir (máximo %d)? ", MAX);
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        fprintf(stderr, "Cantidad inválida.\n");
        return 1;
    }
    for (int i = 0; i < n; i++) {
        printf("Introduce el número %d: ", i + 1);
        if (scanf("%d", &numeros[i]) != 1) {
            fprintf(stderr, "Entrada inválida.\n");
            return 1;
        }
        long long valor = numeros[i];
        if ((valor > 0 && suma > LLONG_MAX - valor) ||
            (valor < 0 && suma < LLONG_MIN - valor)) {
            fprintf(stderr, "La suma no cabe en long long.\n");
            return 1;
        }
        suma += valor;
    }
    printf("La suma de los %d números es: %lld\n", n, suma);
    printf("El promedio es: %.2f\n", (double)suma / n);
    return 0;
}
