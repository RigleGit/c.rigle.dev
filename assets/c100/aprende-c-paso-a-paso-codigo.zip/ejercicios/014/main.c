#include <stdio.h>

int main(void) {
    int a, b, c;

    // Solicita al usuario que introduzca tres números enteros
    printf("Introduce tres números enteros separados por espacios: ");
    if (scanf("%d %d %d", &a, &b, &c) != 3) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Compara los números para determinar cuál es el mayor
    if (a >= b && a >= c) {
        printf("El mayor es: %d\n", a);
    } else if (b >= a && b >= c) {
        printf("El mayor es: %d\n", b);
    } else {
        printf("El mayor es: %d\n", c);
    }

    return 0;
}
