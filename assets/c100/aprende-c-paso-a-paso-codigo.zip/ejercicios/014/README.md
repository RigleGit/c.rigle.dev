# Ejercicio 14

Fuente: 018-ejercicio-14-mayor-de-tres-n-umeros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
