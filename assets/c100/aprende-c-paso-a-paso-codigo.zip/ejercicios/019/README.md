# Ejercicio 19

Fuente: 023-ejercicio-19-tri-angulo-de-asteriscos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
