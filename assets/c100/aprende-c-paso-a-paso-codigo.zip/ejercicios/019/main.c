#include <stdio.h>

int main(void) {
    int n;

    // Solicitar al usuario el número de filas
    printf("Introduce el número de filas: ");
    if (scanf("%d", &n) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (n <= 0) {
        fputs("El número de filas debe ser positivo.\n", stderr);
        return 1;
    }

    // Bucle externo para las filas, con índices desde cero
    for (int i = 0; i < n; i++) {
        // Bucle interno para imprimir asteriscos en cada fila
        for (int j = 0; j <= i; j++) {
            printf("*");
        }
        // Saltar a la siguiente línea después de cada fila
        printf("\n");
    }

    return 0;
}
