#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>

#define PUERTO 8080
#define BUFFER 1024

int main(void) {
    int servidor_fd, cliente_fd;
    int estado = 0;
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
        perror("signal");
        return 1;
    }
    struct sockaddr_in direccion_servidor = {0}, direccion_cliente;
    socklen_t tam_cliente = sizeof(direccion_cliente);
    char buffer[BUFFER];

    // Crear socket TCP
    servidor_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (servidor_fd < 0) {
        perror("Error al crear el socket");
        exit(EXIT_FAILURE);
    }

    // Configurar dirección del servidor
    direccion_servidor.sin_family = AF_INET;
    direccion_servidor.sin_addr.s_addr = htonl(INADDR_ANY);
    direccion_servidor.sin_port = htons(PUERTO);

    // Asociar socket con puerto
    if (bind(servidor_fd, (struct sockaddr *)&direccion_servidor, sizeof(direccion_servidor)) < 0) {
        perror("Error en bind");
        close(servidor_fd);
        exit(EXIT_FAILURE);
    }

    // Escuchar conexiones entrantes
    if (listen(servidor_fd, 1) < 0) {
        perror("Error en listen");
        close(servidor_fd);
        exit(EXIT_FAILURE);
    }

    printf("Servidor esperando conexión en puerto %d...\n", PUERTO);

    // Aceptar conexión entrante
    do {
        tam_cliente = sizeof(direccion_cliente);
        cliente_fd = accept(servidor_fd, (struct sockaddr *)&direccion_cliente, &tam_cliente);
    } while (cliente_fd < 0 && errno == EINTR);
    if (cliente_fd < 0) {
        perror("Error en accept");
        close(servidor_fd);
        exit(EXIT_FAILURE);
    }

    // Devolver el flujo hasta que el cliente termine su envío.
    for (;;) {
        ssize_t leido;
        do {
            leido = recv(cliente_fd, buffer, sizeof(buffer), 0);
        } while (leido < 0 && errno == EINTR);
        if (leido < 0) {
            perror("Error al recibir datos");
            estado = 1;
            break;
        }
        if (leido == 0) break;
        printf("Fragmento recibido: %zd bytes\n", leido);

        ssize_t enviados = 0;
        while (enviados < leido) {
            ssize_t n = send(cliente_fd, buffer + enviados,
                             (size_t)(leido - enviados), 0);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) {
                fputs("No se pudo completar el eco.\n", stderr);
                estado = 1;
                break;
            }
            enviados += n;
        }
        if (estado != 0) break;
    }

    // Cerrar conexiones
    close(cliente_fd);
    close(servidor_fd);

    return estado;
}
