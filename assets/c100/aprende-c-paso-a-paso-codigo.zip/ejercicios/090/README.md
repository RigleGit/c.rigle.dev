# Ejercicio 90

Fuente: 094-ejercicio-90-servidor-tcp-eco.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
