#include <stdio.h>
#include <pthread.h>

#define NUM_INCREMENTOS 100000

int contador = 0; // Variable global compartida

// Función que ejecuta cada hilo: incrementa la variable contador NUM_INCREMENTOS veces
void* incrementar(void* arg) {
    (void)arg;
    for (int i = 0; i < NUM_INCREMENTOS; i++) {
        contador++; // Acceso no protegido, condición de carrera
    }
    return NULL;
}

int main(void) {
    pthread_t hilo1, hilo2;

    // Creación de los dos hilos que ejecutan la función incrementar
    pthread_create(&hilo1, NULL, incrementar, NULL);
    pthread_create(&hilo2, NULL, incrementar, NULL);

    // Espera a que ambos hilos terminen su ejecución
    pthread_join(hilo1, NULL);
    pthread_join(hilo2, NULL);

    // Mostrar el valor esperado y el valor real obtenido
    printf("Valor esperado: %d\n", NUM_INCREMENTOS * 2);
    printf("Valor real: %d\n", contador);

    return 0;
}
