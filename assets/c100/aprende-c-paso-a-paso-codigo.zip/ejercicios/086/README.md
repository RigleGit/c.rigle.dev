# Ejercicio 86

Carrera de datos deliberada: no es una solución correcta.
Fuente: 090-ejercicio-86-condici-on-de-carrera.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
