#include <stdio.h>

int main(void) {
    unsigned int numero;

    // Solicitar al usuario que introduzca un número entero
    printf("Introduce un entero no negativo: ");
    if (scanf("%u", &numero) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Comprobar si el bit menos significativo es 0 (número par)
    if ((numero & 1) == 0) {
        printf("%u es par.\n", numero);
    } else {
        printf("%u es impar.\n", numero);
    }

    return 0;
}
