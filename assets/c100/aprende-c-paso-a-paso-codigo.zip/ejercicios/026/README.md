# Ejercicio 26

Fuente: 030-ejercicio-26-comprobar-paridad-con-operadores-de-bit.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
