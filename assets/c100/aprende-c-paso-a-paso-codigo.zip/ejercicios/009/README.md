# Ejercicio 9

Fuente: 013-ejercicio-9-bucles-while-y-do-while.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
