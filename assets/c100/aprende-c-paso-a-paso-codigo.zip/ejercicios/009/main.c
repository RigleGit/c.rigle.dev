#include <stdio.h>

int main(void) {
    int a, b, temp;

    printf("Introduce dos números enteros: ");
    scanf("%d %d", &a, &b);

    printf("Antes del intercambio: a = %d, b = %d\n", a, b);

    temp = a;
    a = b;
    b = temp;

    printf("Después del intercambio: a = %d, b = %d\n", a, b);

    return 0;
}
