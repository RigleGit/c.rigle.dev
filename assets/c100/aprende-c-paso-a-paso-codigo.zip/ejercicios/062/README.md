# Ejercicio 62

Fuente: 066-ejercicio-62-estructura-con-campos-de-bits.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
