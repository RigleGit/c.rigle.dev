#include <stdio.h>

// Definición de la estructura con campos de bits
typedef struct {
    unsigned int activo      : 1; // Flag de estado: activo (1 bit)
    unsigned int conectado   : 1; // Flag de estado: conectado (1 bit)
    unsigned int error       : 1; // Flag de estado: error (1 bit)
    unsigned int modo_debug  : 1; // Flag de estado: modo debug (1 bit)
    unsigned int reservado   : 4; // 4 bits reservados
} Estado;

int main(void) {
    Estado e = {0};

    // Asignación de valores a los campos de bits
    e.activo = 1;
    e.conectado = 0;
    e.error = 1;
    e.modo_debug = 1;

    // Mostrar el estado de cada flag
    printf("Estado:\n");
    printf(" Activo: %u\n", (unsigned int)e.activo);
    printf(" Conectado: %u\n", (unsigned int)e.conectado);
    printf(" Error: %u\n", (unsigned int)e.error);
    printf(" Modo debug: %u\n", (unsigned int)e.modo_debug);

    // Mostrar el tamaño total ocupado por la estructura
    printf("Tamaño de la estructura: %zu bytes\n", sizeof(Estado));

    return 0;
}
