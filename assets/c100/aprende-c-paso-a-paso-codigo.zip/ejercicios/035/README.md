# Ejercicio 35

Fuente: 039-ejercicio-35-ordenar-un-array-m-etodo-burbuja.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
