#include <stdio.h>

#define MAX 100

int main(void) {
    int numeros[MAX];
    int n, temp;

    // Solicitar la cantidad de números a ordenar
    printf("¿Cuántos números quieres ordenar (máximo %d)? ", MAX);
    if (scanf("%d", &n) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (n < 1 || n > MAX) {
        printf("Cantidad inválida.\n");
        return 1;
    }

    // Leer los números en el array
    for (int i = 0; i < n; i++) {
        printf("Introduce el número %d: ", i + 1);
        if (scanf("%d", &numeros[i]) != 1) {
            fputs("Entrada inválida.\n", stderr);
            return 1;
        }
    }

    // Algoritmo de ordenamiento burbuja
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (numeros[j] > numeros[j + 1]) {
                // Intercambiar elementos adyacentes
                temp = numeros[j];
                numeros[j] = numeros[j + 1];
                numeros[j + 1] = temp;
            }
        }
    }

    // Mostrar el array ordenado
    printf("Array ordenado:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    return 0;
}
