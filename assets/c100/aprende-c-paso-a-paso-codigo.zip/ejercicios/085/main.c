#include <stdio.h>           // Inclusión de librerías estándar
#include <pthread.h>         // Inclusión de la librería de hilos POSIX

#include <stdlib.h>
#include <string.h>

static void comprobar_pthread(int error, const char *operacion) {
    if (error != 0) {
        fprintf(stderr, "%s: %s\n", operacion, strerror(error));
        exit(EXIT_FAILURE);
    }
}

#define TAMANO_ARRAY 10      // Definición del tamaño del array

int array[TAMANO_ARRAY] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Array de enteros
int suma1 = 0, suma2 = 0;    // Variables globales para los resultados parciales

// Función que suma la primera mitad del array
void* sumarPrimeraMitad(void* arg) {
    (void)arg;
    for (int i = 0; i < TAMANO_ARRAY / 2; i++) {
        suma1 += array[i];
    }
    return NULL;
}

// Función que suma la segunda mitad del array
void* sumarSegundaMitad(void* arg) {
    (void)arg;
    for (int i = TAMANO_ARRAY / 2; i < TAMANO_ARRAY; i++) {
        suma2 += array[i];
    }
    return NULL;
}

int main(void) {
    pthread_t hilo1, hilo2;  // Declaración de los identificadores de hilo

    // Crear los dos hilos, uno para cada mitad del array
    comprobar_pthread(pthread_create(&hilo1, NULL, sumarPrimeraMitad, NULL), "pthread_create");
    comprobar_pthread(pthread_create(&hilo2, NULL, sumarSegundaMitad, NULL), "pthread_create");

    // Esperar a que ambos hilos terminen su ejecución
    comprobar_pthread(pthread_join(hilo1, NULL), "pthread_join");
    comprobar_pthread(pthread_join(hilo2, NULL), "pthread_join");

    // Sumar los resultados parciales y mostrar el total
    int sumaTotal = suma1 + suma2;
    printf("Suma total: %d\n", sumaTotal);
    return 0;
}
