# Ejercicio 85

Fuente: 089-ejercicio-85-suma-en-paralelo-con-2-hilos.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
