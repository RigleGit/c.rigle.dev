# Ejercicio 38

Fuente: 042-ejercicio-38-longitud-de-una-cadena-implementaci-on-de-strlen-propia.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
