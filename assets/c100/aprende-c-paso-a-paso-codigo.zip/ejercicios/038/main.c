#include <stdio.h>

int main(void) {
    char cadena[100];  // Array para almacenar la cadena ingresada
    int longitud = 0;  // Contador para la longitud de la cadena

    printf("Introduce una cadena: ");
    if (fgets(cadena, sizeof(cadena), stdin) == NULL) {
        return 1;
    }

    // Recorrer la cadena hasta encontrar '\0' o '\n'
    while (cadena[longitud] != '\0' && cadena[longitud] != '\n') {
        longitud++;
    }

    // Comprobar que se ha leído la línea completa
    if (cadena[longitud] != '\n') {
        int siguiente = getchar();
        if (siguiente != '\n' && (siguiente != EOF || ferror(stdin))) {
            fputs("Línea demasiado larga o error de lectura.\n",
                  stderr);
            return 1;
        }
    }

    printf("La longitud de la cadena es: %d\n", longitud);

    return 0;
}
