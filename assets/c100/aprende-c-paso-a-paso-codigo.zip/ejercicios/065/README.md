# Ejercicio 65

Fuente: 069-ejercicio-65-invertir-una-lista-enlazada.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
