#include <stdio.h>
#include <stdlib.h>

// Definición de la estructura Nodo
typedef struct Nodo {
    int valor;
    struct Nodo* siguiente;
} Nodo;

// Inserta un nuevo nodo al final de la lista
void insertarFinal(Nodo** cabeza, int valor) {
    Nodo* nuevo = malloc(sizeof(Nodo));
    if (nuevo == NULL) {
        fprintf(stderr, "Error al asignar memoria\n");
        exit(EXIT_FAILURE);
    }
    nuevo->valor = valor;
    nuevo->siguiente = NULL;

    if (*cabeza == NULL) {
        *cabeza = nuevo;
    } else {
        Nodo* temp = *cabeza;
        while (temp->siguiente != NULL) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevo;
    }
}

// Imprime la lista enlazada
void imprimirLista(Nodo* cabeza) {
    while (cabeza != NULL) {
        printf("%d -> ", cabeza->valor);
        cabeza = cabeza->siguiente;
    }
    printf("NULL\n");
}

// Invierte la lista enlazada utilizando punteros auxiliares
void invertirLista(Nodo** cabeza) {
    Nodo* prev = NULL;
    Nodo* actual = *cabeza;
    Nodo* siguiente = NULL;

    while (actual != NULL) {
        siguiente = actual->siguiente;  // Guardar siguiente nodo
        actual->siguiente = prev;        // Invertir enlace
        prev = actual;                   // Mover prev y actual
        actual = siguiente;
    }
    *cabeza = prev;  // Nueva cabeza de la lista
}

int main(void) {
    Nodo* lista = NULL;

    insertarFinal(&lista, 1);
    insertarFinal(&lista, 2);
    insertarFinal(&lista, 3);
    insertarFinal(&lista, 4);

    printf("Lista original:\n");
    imprimirLista(lista);

    invertirLista(&lista);

    printf("Lista invertida:\n");
    imprimirLista(lista);

    // Liberar todos los nodos al terminar
    Nodo* temp;
    while (lista != NULL) {
        temp = lista;
        lista = lista->siguiente;
        free(temp);
    }

    return 0;
}
