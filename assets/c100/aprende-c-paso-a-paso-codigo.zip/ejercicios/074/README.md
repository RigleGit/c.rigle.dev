# Ejercicio 74

Fuente: 078-ejercicio-74-leer-un-archivo-de-texto.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
