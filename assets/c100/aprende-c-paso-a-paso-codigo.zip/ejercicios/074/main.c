#include <stdio.h>

int main(void) {
    char linea[256];
    FILE *f = fopen("salida.txt", "r");
    if (f == NULL) {
        perror("No se pudo abrir el archivo");
        return 1;
    }

    printf("Contenido del archivo:\n");
    int error = 0;
    while (fgets(linea, sizeof linea, f) != NULL) {
        if (fputs(linea, stdout) == EOF) {
            error = 1;
            break;
        }
    }
    if (ferror(f)) error = 1;
    if (fclose(f) == EOF) error = 1;
    if (fflush(stdout) == EOF) error = 1;
    if (error) {
        fputs("No se pudo completar la lectura, salida o cierre.\n", stderr);
        return 1;
    }
    return 0;
}
