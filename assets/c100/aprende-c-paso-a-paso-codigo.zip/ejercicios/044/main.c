#include <stdio.h>

// Función que intercambia los valores de dos enteros usando punteros
void swap(int *a, int *b) {
    int temp = *a;  // Guardar el valor apuntado por 'a' en 'temp'
    *a = *b;        // Asignar el valor apuntado por 'b' a la dirección apuntada por 'a'
    *b = temp;      // Asignar el valor temporal a la dirección apuntada por 'b'
}

int main(void) {
    int x = 5, y = 10;

    printf("Antes del intercambio:\n");
    printf("x = %d, y = %d\n", x, y);

    swap(&x, &y); // Pasar las direcciones de x e y para modificar sus valores

    printf("Después del intercambio:\n");
    printf("x = %d, y = %d\n", x, y);

    return 0;
}
