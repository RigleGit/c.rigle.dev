# Ejercicio 97

Fuente: 101-ejercicio-97-uso-de-const-en-par-ametros-y-variables.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
