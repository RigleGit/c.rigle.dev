#include <stdio.h>
#include <string.h>

// 'cadena' no se modifica, se marca como const
int longitud_cadena(const char *cadena) {
    return strlen(cadena);
}

// 'mensaje' tampoco se modifica
void imprimir_mensaje(const char *mensaje) {
    printf("Mensaje: %s\n", mensaje);
}

int main(void) {
    const char saludo[] = "Hola, mundo!";
    const int valor = 42; // No debe cambiar
    imprimir_mensaje(saludo);
    printf("Longitud: %d\n", longitud_cadena(saludo));
    printf("Valor: %d\n", valor);
    // valor = 43; // El compilador dará error: variable constante
    return 0;
}
