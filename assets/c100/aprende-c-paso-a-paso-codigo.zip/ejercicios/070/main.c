#include <stdio.h>
#include <stdlib.h>

// Definición del nodo de la lista doblemente enlazada
typedef struct Nodo {
    int valor;
    struct Nodo *siguiente;
    struct Nodo *anterior;
} Nodo;

// Inserta un nuevo nodo al final de la lista
Nodo *insertarFinal(Nodo *cabeza, int valor) {
    Nodo *nuevo = (Nodo *)malloc(sizeof(Nodo));
    if (nuevo == NULL) {
        fprintf(stderr, "Error al reservar memoria.\n");
        exit(EXIT_FAILURE);
    }
    nuevo->valor = valor;
    nuevo->siguiente = NULL;
    nuevo->anterior = NULL;

    if (cabeza == NULL) {
        return nuevo; // la lista estaba vacía
    }

    Nodo *actual = cabeza;
    while (actual->siguiente != NULL) {
        actual = actual->siguiente;
    }
    actual->siguiente = nuevo;
    nuevo->anterior = actual;
    return cabeza;
}

// Recorre desde la cabeza hacia adelante
void recorrerAdelante(Nodo *cabeza) {
    printf("Recorrido hacia adelante:\n");
    while (cabeza != NULL) {
        printf("%d ", cabeza->valor);
        cabeza = cabeza->siguiente;
    }
    printf("\n");
}

// Recorre desde la cola hacia atrás
void recorrerAtras(Nodo *cola) {
    printf("Recorrido hacia atrás:\n");
    while (cola != NULL) {
        printf("%d ", cola->valor);
        cola = cola->anterior;
    }
    printf("\n");
}

// Devuelve el último nodo (cola) de la lista
Nodo *obtenerUltimo(Nodo *cabeza) {
    if (cabeza == NULL) return NULL;
    while (cabeza->siguiente != NULL) {
        cabeza = cabeza->siguiente;
    }
    return cabeza;
}

// Libera la lista completa desde la cabeza
void liberarLista(Nodo *cabeza) {
    while (cabeza != NULL) {
        Nodo *temp = cabeza;
        cabeza = cabeza->siguiente;
        free(temp);
    }
}

int main(void) {
    Nodo *lista = NULL;

    lista = insertarFinal(lista, 10);
    lista = insertarFinal(lista, 20);
    lista = insertarFinal(lista, 30);

    recorrerAdelante(lista);

    Nodo *cola = obtenerUltimo(lista);
    recorrerAtras(cola);

    liberarLista(lista);
    return 0;
}
