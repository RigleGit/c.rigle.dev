# Ejercicio 70

Fuente: 074-ejercicio-70-b-usqueda-en-arbol-binario.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
