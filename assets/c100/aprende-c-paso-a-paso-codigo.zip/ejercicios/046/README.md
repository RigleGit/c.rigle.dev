# Ejercicio 46

Fuente: 050-ejercicio-46-copiar-una-cadena-implementaci-on-de-strcpy.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
