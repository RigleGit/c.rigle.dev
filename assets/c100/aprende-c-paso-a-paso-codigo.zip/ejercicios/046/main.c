#include <stdio.h>

void copiarCadena(char *dest, const char *orig) {
    // Copiar cada carácter de orig a dest hasta encontrar el terminador '\0'
    while (*orig != '\0') {
        *dest = *orig;
        dest++;
        orig++;
    }
    // Añadir el carácter terminador al final de la cadena destino
    *dest = '\0';
}

int main(void) {
    char origen[] = "Hola, mundo!";
    char destino[50]; // Asegurarse de que hay suficiente espacio en destino

    copiarCadena(destino, origen);
    printf("Cadena copiada: %s\n", destino);

    return 0;
}
