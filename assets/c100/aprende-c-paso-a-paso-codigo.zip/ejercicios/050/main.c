#include <stdio.h>

int main(void) {
    int a = 42;
    float b = 3.14f;
    char c = 'Z';

    void *ptr;

    // Apuntar a un int y mostrar su valor
    ptr = &a;
    printf("Valor de a: %d\n", *(int *)ptr);

    // Apuntar a un float y mostrar su valor
    ptr = &b;
    printf("Valor de b: %.2f\n", *(float *)ptr);

    // Apuntar a un char y mostrar su valor
    ptr = &c;
    printf("Valor de c: %c\n", *(char *)ptr);

    return 0;
}
