# Ejercicio 50

Fuente: 054-ejercicio-50-volatilidad.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
