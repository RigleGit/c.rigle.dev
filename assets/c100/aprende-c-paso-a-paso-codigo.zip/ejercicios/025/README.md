# Ejercicio 25

Fuente: 029-ejercicio-25-funci-on-potencia.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
