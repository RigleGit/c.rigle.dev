#include <stdio.h>
#include <math.h>

double potencia(double base, int exp) {
    unsigned magnitud = exp < 0 ? 0u - (unsigned)exp : (unsigned)exp;
    if (exp < 0) base = 1.0 / base;
    double resultado = 1.0;
    while (magnitud != 0) {
        if (magnitud % 2u != 0) resultado *= base;
        magnitud /= 2u;
        if (magnitud != 0) base *= base;
    }
    return resultado;
}

int main(void) {
    double base;
    int exp;
    printf("Introduce la base: ");
    if (scanf("%lf", &base) != 1 || !isfinite(base)) {
        fprintf(stderr, "Base inválida.\n");
        return 1;
    }
    printf("Introduce el exponente entero: ");
    if (scanf("%d", &exp) != 1 || (base == 0.0 && exp < 0)) {
        fprintf(stderr, "Exponente inválido para esta base.\n");
        return 1;
    }
    double resultado = potencia(base, exp);
    if (!isfinite(resultado)) {
        fprintf(stderr, "Resultado no representable como double finito.\n");
        return 1;
    }
    printf("%.2f elevado a %d es: %.5f\n", base, exp, resultado);
    return 0;
}
