#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>

int main(void) {
    int n;
    printf("Introduce el número de elementos (1-1000): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 1000 ||
        (size_t)n > SIZE_MAX / sizeof(int)) {
        fprintf(stderr, "Tamaño inválido.\n");
        return 1;
    }
    int *arr = malloc((size_t)n * sizeof *arr);
    if (arr == NULL) {
        fprintf(stderr, "No se pudo reservar memoria.\n");
        return 1;
    }
    long long suma = 0;
    for (int i = 0; i < n; i++) {
        printf("Introduce el elemento %d: ", i + 1);
        if (scanf("%d", &arr[i]) != 1) {
            free(arr);
            return 1;
        }
        long long valor = arr[i];
        if ((valor > 0 && suma > LLONG_MAX - valor) ||
            (valor < 0 && suma < LLONG_MIN - valor)) {
            fprintf(stderr, "Suma no representable.\n");
            free(arr);
            return 1;
        }
        suma += valor;
    }
    printf("Suma: %lld\n", suma);
    printf("Promedio: %.2f\n", (double)suma / n);
    free(arr);
    return 0;
}
