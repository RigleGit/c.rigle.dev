# Ejercicio 52

Fuente: 056-ejercicio-52-array-din-amico-de-n-enteros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
