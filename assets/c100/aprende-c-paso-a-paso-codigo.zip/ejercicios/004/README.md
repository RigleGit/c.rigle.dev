# Ejercicio 4

Fuente: 008-ejercicio-4-area-de-un-c-irculo.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
