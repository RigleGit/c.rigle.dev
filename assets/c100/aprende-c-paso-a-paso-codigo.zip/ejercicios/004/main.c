#include <stdio.h>

int main(void) {
    double radio, area;
    double pi = 3.1416;

    printf("Introduce el radio del círculo: ");
    scanf("%lf", &radio);

    area = pi * radio * radio;

    printf("El área del círculo es %.2f\n", area);

    return 0;
}
