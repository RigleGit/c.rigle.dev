#include <stdio.h>

int main(void) {
    unsigned int numero;
    int cuenta = 0;

    printf("Introduce un entero no negativo: ");
    if (scanf("%u", &numero) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    while (numero != 0) {
        // Comprobar si el bit menos significativo es 1
        if (numero & 1) {
            cuenta++;
        }
        // Desplazar los bits una posición a la derecha
        numero >>= 1;
    }

    printf("Número de bits a 1: %d\n", cuenta);

    return 0;
}
