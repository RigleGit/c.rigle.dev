# Ejercicio 27

Fuente: 031-ejercicio-27-contar-bits-a-1-en-un-n-umero.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
