# Ejercicio 75

Fuente: 079-ejercicio-75-programaci-on-as-incrona.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
