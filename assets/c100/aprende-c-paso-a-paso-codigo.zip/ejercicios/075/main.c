#include <stdio.h>

int main(void) {
    FILE *origen = fopen("origen.txt", "r");
    if (origen == NULL) {
        perror("No se pudo abrir el origen");
        return 1;
    }
    FILE *destino = fopen("copia.txt", "w");
    if (destino == NULL) {
        perror("No se pudo abrir el destino");
        fclose(origen);
        return 1;
    }
    char buffer[256];
    int error = 0;
    while (fgets(buffer, sizeof buffer, origen) != NULL) {
        if (fputs(buffer, destino) == EOF) {
            error = 1;
            break;
        }
    }
    if (ferror(origen)) error = 1;
    if (fclose(origen) == EOF) error = 1;
    if (fclose(destino) == EOF) error = 1;
    if (error) {
        fprintf(stderr, "No se pudo completar la copia.\n");
        return 1;
    }
    puts("Archivo copiado correctamente.");
    return 0;
}
