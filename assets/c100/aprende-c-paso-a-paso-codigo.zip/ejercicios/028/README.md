# Ejercicio 28

Fuente: 032-ejercicio-28-verificar-si-un-n-umero-es-potencia-de-2.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
