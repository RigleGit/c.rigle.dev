#include <stdio.h>
#include <stdbool.h>

// Función que verifica si n es potencia de 2
bool esPotenciaDe2(unsigned int n) {
    // Un número es potencia de 2 si no es cero y tiene un solo bit en 1
    return n != 0 && (n & (n - 1)) == 0;
}

int main(void) {
    unsigned int numero;

    printf("Introduce un entero no negativo: ");
    if (scanf("%u", &numero) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    if (esPotenciaDe2(numero)) {
        printf("%u es una potencia de 2.\n", numero);
    } else {
        printf("%u NO es una potencia de 2.\n", numero);
    }

    return 0;
}
