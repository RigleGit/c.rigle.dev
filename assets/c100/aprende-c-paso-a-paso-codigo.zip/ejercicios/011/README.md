# Ejercicio 11

Fuente: 015-ejercicio-11-n-umero-par-o-impar.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
