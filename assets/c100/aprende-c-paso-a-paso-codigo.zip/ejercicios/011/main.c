#include <stdio.h>

int main(void) {
    int numero;

    // Solicitar al usuario que introduzca un número entero
    printf("Introduce un número entero: ");
    if (scanf("%d", &numero) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Comprobar si el número es par o impar
    if (numero % 2 == 0) {
        printf("El número %d es par.\n", numero);
    } else {
        printf("El número %d es impar.\n", numero);
    }

    return 0;
}
