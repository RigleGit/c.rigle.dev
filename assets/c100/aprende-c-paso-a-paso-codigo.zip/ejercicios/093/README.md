# Ejercicio 93

Fuente: 097-ejercicio-93-cliente-http-b-asico.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
