#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <errno.h>
#include <signal.h>

#define HOST "example.com"
#define PUERTO "80"

int main(void) {
    struct addrinfo hints = {0}, *direcciones;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    int error = getaddrinfo(HOST, PUERTO, &hints, &direcciones);
    if (error != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(error));
        return 1;
    }
    int sock = -1;
    for (struct addrinfo *p = direcciones; p != NULL; p = p->ai_next) {
        sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sock < 0) continue;
        if (connect(sock, p->ai_addr, p->ai_addrlen) == 0) break;
        close(sock);
        sock = -1;
    }
    freeaddrinfo(direcciones);
    if (sock < 0) {
        fputs("No se pudo conectar a ninguna dirección.\n", stderr);
        return 1;
    }
    int estado = 1;
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
        perror("signal");
        goto cierre;
    }
    const char *peticion =
        "GET / HTTP/1.0\r\nHost: " HOST "\r\nConnection: close\r\n\r\n";
    size_t longitud = strlen(peticion), enviados = 0;
    while (enviados < longitud) {
        ssize_t n = send(sock, peticion + enviados,
                         longitud - enviados, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) {
            fputs("No se pudo completar la petición.\n", stderr);
            goto cierre;
        }
        enviados += (size_t)n;
    }
    char buffer[4096];
    for (;;) {
        ssize_t n = recv(sock, buffer, sizeof(buffer), 0);
        if (n < 0 && errno == EINTR) continue;
        if (n < 0) {
            perror("recv");
            goto cierre;
        }
        if (n == 0) break;
        if (fwrite(buffer, 1, (size_t)n, stdout) != (size_t)n) {
            fputs("Error al escribir la respuesta.\n", stderr);
            goto cierre;
        }
    }
    if (fflush(stdout) == EOF) {
        perror("stdout");
        goto cierre;
    }
    estado = 0;
cierre:
    close(sock);
    return estado;
}
