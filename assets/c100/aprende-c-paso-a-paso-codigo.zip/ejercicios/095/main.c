#include <stdio.h>
#include <string.h>

int main(void) {
    char destino[20];
    char nombre[] = "Rodrigo";
    int edad = 30;

    // Usar strncpy para copiar y asegurar que el string termine en '\0'
    strncpy(destino, "Nombre: ", sizeof(destino) - 1);
    destino[sizeof(destino) - 1] = '\0';

    // Usar strncat para concatenar sin desbordar
    strncat(destino, nombre, sizeof(destino) - strlen(destino) - 1);

    printf("%s\n", destino);

    // Otra cadena para mostrar el uso de snprintf correctamente
    char info[20];
    snprintf(info, sizeof(info), "Edad: %d", edad);
    printf("%s\n", info);

    return 0;
}
