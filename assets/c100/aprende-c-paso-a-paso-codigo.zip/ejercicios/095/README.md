# Ejercicio 95

Fuente: 099-ejercicio-95-sustituir-funciones-inseguras.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
