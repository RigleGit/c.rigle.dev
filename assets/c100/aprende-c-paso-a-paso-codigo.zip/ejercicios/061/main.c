#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nombre[50];
    int edad;
} Persona;

int main(void) {
    // Reserva dinámica de memoria para una Persona
    Persona *p = (Persona *) malloc(sizeof(Persona));
    if (p == NULL) {
        printf("Error al asignar memoria.\n");
        return 1;
    }

    // Asignación de valores a los campos
    strcpy(p->nombre, "Rodrigo");
    p->edad = 35;

    // Mostrar la información
    printf("Nombre: %s\n", p->nombre);
    printf("Edad: %d\n", p->edad);

    // Liberar la memoria reservada
    free(p);
    p = NULL;

    return 0;
}
