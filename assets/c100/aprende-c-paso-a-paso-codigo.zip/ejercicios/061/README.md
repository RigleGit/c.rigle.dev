# Ejercicio 61

Fuente: 065-ejercicio-61-reserva-din-amica-de-una-estructura.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
