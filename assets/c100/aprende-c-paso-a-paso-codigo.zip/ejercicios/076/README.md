# Ejercicio 76

Fuente: 080-ejercicio-76-contar-l-ineas-palabras-y-caracteres.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
