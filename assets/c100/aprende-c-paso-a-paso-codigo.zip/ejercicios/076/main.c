#include <stdio.h>
#include <ctype.h>

int main(void) {
    FILE *archivo = fopen("entrada.txt", "rb");
    if (archivo == NULL) {
        perror("No se pudo abrir el archivo");
        return 1;
    }
    size_t bytes = 0, palabras = 0, lineas = 0;
    int en_palabra = 0;
    int c;
    while ((c = fgetc(archivo)) != EOF) {
        bytes++;
        if (c == '\n') lineas++;
        if (isspace(c)) en_palabra = 0;
        else if (!en_palabra) {
            en_palabra = 1;
            palabras++;
        }
    }
    int error = ferror(archivo);
    if (fclose(archivo) == EOF) error = 1;
    if (error) {
        fprintf(stderr, "Error al leer o cerrar el archivo.\n");
        return 1;
    }
    printf("Líneas: %zu\n", lineas);
    printf("Palabras: %zu\n", palabras);
    printf("Bytes: %zu\n", bytes);
    return 0;
}
