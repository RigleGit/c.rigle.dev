# Ejercicio 34

Fuente: 038-ejercicio-34-b-usqueda-lineal-en-un-array.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
