#include <stdio.h>

#define MAX 100

int main(void) {
    int numeros[MAX];
    int n, valor, encontrado = 0;

    // Solicitar al usuario la cantidad de números a introducir
    printf("¿Cuántos números vas a introducir (máximo %d)? ", MAX);
    if (scanf("%d", &n) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Validar la cantidad de números
    if (n < 1 || n > MAX) {
        printf("Cantidad inválida.\n");
        return 1;
    }

    // Leer los números y almacenarlos en el array
    for (int i = 0; i < n; i++) {
        printf("Introduce el número %d: ", i + 1);
        if (scanf("%d", &numeros[i]) != 1) {
            fputs("Entrada inválida.\n", stderr);
            return 1;
        }
    }

    // Solicitar el valor a buscar
    printf("Introduce el valor que deseas buscar: ");
    if (scanf("%d", &valor) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    // Realizar búsqueda lineal en el array
    for (int i = 0; i < n; i++) {
        if (numeros[i] == valor) {
            printf("Valor encontrado en la posición %d (índice %d).\n", i + 1, i);
            encontrado = 1;
            break;
        }
    }

    // Informar si el valor no fue encontrado
    if (!encontrado) {
        printf("Valor no encontrado en el array.\n");
    }

    return 0;
}
