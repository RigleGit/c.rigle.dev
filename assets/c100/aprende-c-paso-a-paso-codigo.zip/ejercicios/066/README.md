# Ejercicio 66

Fuente: 070-ejercicio-66-pila-implementada-con-lista-enlazada.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
