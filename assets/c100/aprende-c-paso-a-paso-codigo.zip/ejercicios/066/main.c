#include <stdio.h>
#include <stdlib.h>

// Definición del nodo de la lista enlazada
typedef struct Nodo {
    int valor;
    struct Nodo* siguiente;
} Nodo;

// Inserta un nuevo elemento en la cima de la pila (push)
void push(Nodo** cima, int valor) {
    Nodo* nuevo = malloc(sizeof(Nodo));
    if (nuevo == NULL) {
        printf("Error de asignación de memoria.\n");
        exit(1);
    }
    nuevo->valor = valor;
    nuevo->siguiente = *cima;
    *cima = nuevo;
}

// Retira y devuelve el elemento de la cima de la pila (pop)
int pop(Nodo** cima) {
    if (*cima == NULL) {
        printf("Pila vacía.\n");
        return -1; // Código de error o valor especial
    }
    Nodo* temp = *cima;
    int valor = temp->valor;
    *cima = temp->siguiente;
    free(temp);
    return valor;
}

// Devuelve el valor del tope sin eliminarlo (peek)
int peek(Nodo* cima) {
    if (cima == NULL) {
        printf("Pila vacía.\n");
        return -1;
    }
    return cima->valor;
}

// Imprime el contenido de la pila desde la cima
void imprimirPila(Nodo* cima) {
    printf("Pila: ");
    while (cima != NULL) {
        printf("%d -> ", cima->valor);
        cima = cima->siguiente;
    }
    printf("NULL\n");
}

int main(void) {
    Nodo* pila = NULL;

    push(&pila, 10);
    push(&pila, 20);
    push(&pila, 30);

    imprimirPila(pila);

    printf("Tope: %d\n", peek(pila));

    printf("Pop: %d\n", pop(&pila));

    imprimirPila(pila);

    while (pila != NULL) {
        (void)pop(&pila);
    }
    return 0;
}
