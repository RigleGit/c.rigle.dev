# Ejercicio 58

Fuente: 062-ejercicio-58-arreglo-de-estructuras.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
