#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 100
#define MAX_PERSONAS 5

typedef struct {
    char nombre[MAX_NOMBRE];
    int edad;
} Persona;

// Función que imprime las personas con edad mayor a edadLimite
void imprimirMayoresDe(Persona personas[], int tam, int edadLimite) {
    printf("Personas mayores de %d años:\n", edadLimite);
    for (int i = 0; i < tam; i++) {
        if (personas[i].edad > edadLimite) {
            printf("- %s (%d años)\n", personas[i].nombre, personas[i].edad);
        }
    }
}

int main(void) {
    Persona lista[MAX_PERSONAS];

    // Entrada de datos para cada persona
    for (int i = 0; i < MAX_PERSONAS; i++) {
        printf("Introduce el nombre de la persona %d: ", i + 1);
        if (fgets(lista[i].nombre, MAX_NOMBRE, stdin) == NULL) return 1;
        size_t longitud = strcspn(lista[i].nombre, "\n");
        if (longitud > 98 ||
            (lista[i].nombre[longitud] != '\n' && !feof(stdin))) {
            fputs("Nombre demasiado largo.\n", stderr);
            return 1;
        }
        // Eliminar salto de línea al final
        lista[i].nombre[longitud] = '\0';

        printf("Introduce la edad de %s: ", lista[i].nombre);
        if (scanf("%d", &lista[i].edad) != 1 ||
            lista[i].edad < 0 || lista[i].edad > 150) return 1;
        int c;
        while ((c = getchar()) != '\n' && c != EOF) {}
        if (c == EOF && i + 1 < MAX_PERSONAS) return 1;
    }

    // Imprimir personas mayores de 30 años
    imprimirMayoresDe(lista, MAX_PERSONAS, 30);

    return 0;
}
