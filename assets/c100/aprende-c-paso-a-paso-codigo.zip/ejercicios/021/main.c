#include <stdio.h>

// Función que devuelve el mayor de dos enteros
int max(int a, int b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

int main(void) {
    int x, y;

    printf("Introduce el primer número: ");
    if (scanf("%d", &x) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    printf("Introduce el segundo número: ");
    if (scanf("%d", &y) != 1) {
        fputs("Entrada inválida.\n", stderr);
        return 1;
    }

    int resultado = max(x, y);

    printf("El número mayor es: %d\n", resultado);

    return 0;
}
