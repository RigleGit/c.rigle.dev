# Ejercicio 21

Fuente: 025-ejercicio-21-funci-on-m-aximo-de-dos-n-umeros.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
