#include <stdio.h>

int main(void) {
    double radio, volumen;
    double pi = 3.1416;

    printf("Introduce el radio de la esfera: ");
    scanf("%lf", &radio);

    volumen = (4.0 / 3.0) * pi * radio * radio * radio;

    printf("El volumen de la esfera es: %.2f\n", volumen);

    return 0;
}
