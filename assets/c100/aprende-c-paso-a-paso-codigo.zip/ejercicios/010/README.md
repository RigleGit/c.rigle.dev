# Ejercicio 10

Fuente: 014-ejercicio-10-volumen-de-una-esfera.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
