# Ejercicio 42

Fuente: 046-ejercicio-42-b-usqueda-de-subcadena-sin-strstr.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
