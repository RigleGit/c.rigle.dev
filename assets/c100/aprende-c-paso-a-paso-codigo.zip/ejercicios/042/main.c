#include <stdio.h>

// Leer una línea completa sin almacenar su salto final
int leerLinea(char cadena[], int capacidad) {
    if (fgets(cadena, capacidad, stdin) == NULL) return 0;
    int i = 0;
    while (cadena[i] != '\0' && cadena[i] != '\n') i++;
    if (cadena[i] == '\n') {
        cadena[i] = '\0';
    } else {
        // Si el array se llenó, comprobar el carácter pendiente
        int siguiente = getchar();
        if (siguiente != '\n' &&
            (siguiente != EOF || ferror(stdin))) {
            fputs("Línea demasiado larga o error de lectura.\n", stderr);
            return 0;
        }
    }
    return 1;
}

// Función que busca la subcadena en la cadena principal
int buscarSubcadena(const char *cadena, const char *subcadena) {
    int i, j;
    if (subcadena[0] == '\0') return 0;

    for (i = 0; cadena[i] != '\0'; i++) {
        // Para cada posición en cadena, verificamos si subcadena coincide
        for (j = 0; subcadena[j] != '\0'; j++) {
            // Si los caracteres no coinciden, salimos del ciclo interno
            if (cadena[i + j] != subcadena[j]) {
                break;
            }
        }
        // Si llegamos al final de subcadena, significa que se encontró la coincidencia
        if (subcadena[j] == '\0') {
            return i;
        }
    }
    // Si no se encontró la subcadena, devolvemos -1
    return -1;
}

int main(void) {
    char texto[100], sub[50];

    printf("Introduce el texto principal: ");
    if (!leerLinea(texto, sizeof texto)) {
        return 1;
    }

    printf("Introduce la subcadena a buscar: ");
    if (!leerLinea(sub, sizeof sub)) {
        return 1;
    }

    int posicion = buscarSubcadena(texto, sub);

    if (posicion != -1) {
        printf("Subcadena encontrada en la posición %d\n", posicion);
    } else {
        printf("Subcadena no encontrada\n");
    }

    return 0;
}
