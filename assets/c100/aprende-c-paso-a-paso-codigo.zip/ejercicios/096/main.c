#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

// Función que suma dos enteros comprobando overflow
bool suma_segura(int a, int b, int *resultado) {
    // Detectar overflow positivo
    if (b > 0 && a > INT_MAX - b) {
        return false; // Overflow detectado
    }
    // Detectar overflow negativo
    if (b < 0 && a < INT_MIN - b) {
        return false; // Overflow detectado
    }
    // Suma segura, almacenar resultado
    *resultado = a + b;
    return true;
}

int main(void) {
    int x = INT_MAX - 1;
    int y = 10;
    int res;

    // Prueba con valores cercanos al máximo entero
    if (suma_segura(x, y, &res)) {
        printf("Suma segura: %d + %d = %d\n", x, y, res);
    } else {
        printf("¡Overflow detectado al sumar %d + %d!\n", x, y);
    }

    x = INT_MIN + 2;
    y = -10;

    // Prueba con valores cercanos al mínimo entero
    if (suma_segura(x, y, &res)) {
        printf("Suma segura: %d + %d = %d\n", x, y, res);
    } else {
        printf("¡Overflow detectado al sumar %d + %d!\n", x, y);
    }

    return 0;
}
