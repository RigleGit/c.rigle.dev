# Ejercicio 96

Fuente: 100-ejercicio-96-detectar-overflow-aritm-etico.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
