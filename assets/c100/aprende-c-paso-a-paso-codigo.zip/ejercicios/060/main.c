#include <stdio.h>

// Definición del enum para los días de la semana, iniciando en 1
enum DiaSemana { LUN = 1, MAR, MIE, JUE, VIE, SAB, DOM };

// Función que devuelve el nombre del día según el valor del enum
const char* nombreDia(enum DiaSemana dia) {
    switch (dia) {
        case LUN: return "Lunes";
        case MAR: return "Martes";
        case MIE: return "Miércoles";
        case JUE: return "Jueves";
        case VIE: return "Viernes";
        case SAB: return "Sábado";
        case DOM: return "Domingo";
        default:  return "Día inválido";
    }
}

int main(void) {
    int num;

    // Solicitar al usuario un número del 1 al 7
    printf("Introduce un número del 1 al 7: ");
    if (scanf("%d", &num) != 1) return 1;
    if (num < LUN || num > DOM) {
        fputs("Día: introduce un entero de 1 a 7.\n", stderr);
        return 1;
    }

    // Convertir el número a enum DiaSemana y mostrar el nombre correspondiente
    enum DiaSemana dia = (enum DiaSemana) num;
    printf("Día seleccionado: %s\n", nombreDia(dia));

    return 0;
}
