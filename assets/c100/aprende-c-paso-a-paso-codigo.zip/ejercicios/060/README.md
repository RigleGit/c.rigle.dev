# Ejercicio 60

Fuente: 064-ejercicio-60-enumeraci-on-de-constantes-simb-olicas.md

Compila los archivos indicados en manifest.json con C17 y advertencias. Hilos y redes requieren POSIX: Linux, macOS o WSL.
